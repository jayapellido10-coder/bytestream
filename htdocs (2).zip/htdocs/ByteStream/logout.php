
<?php
session_start();

require_once "config/database.php";
require_once "config/activity.php";

// Record logout before destroying the session
if (isset($_SESSION["user_id"])) {
    logActivity(
        $pdo,
        (int) $_SESSION["user_id"],
        "User logged out"
    );
}

// Clear all session data
$_SESSION = [];

// Destroy the session
session_destroy();

// Return to login page
header("Location: login.php");
exit;
