
<?php
session_start();

// Load database and activity logging
require_once __DIR__ . "/config/database.php";
require_once __DIR__ . "/config/activity.php";

$error = "";
$username = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($username === "" || $password === "") {
        $error = "Please enter your username and password.";
    } else {

        // Find account using username or email
        $stmt = $pdo->prepare("
            SELECT id, username, email, password, role
            FROM users
            WHERE username = ? OR email = ?
            LIMIT 1
        ");

        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user["password"])) {

            // Regenerate session ID
            session_regenerate_id(true);

            // Save account information
            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"];
            $_SESSION["email"] = $user["email"];
            $_SESSION["role"] = $user["role"];

            // Record successful login
            logActivity(
                $pdo,
                (int) $user["id"],
                "User logged in successfully"
            );

            // Redirect based on account role
            if ($user["role"] === "admin") {
                header("Location: admin/dashboard.php");
                exit;
            }

            header("Location: dashboard.php");
            exit;

        } else {
            $error = "Invalid username/email or password.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Sign In | ByteStream</title>

    <link rel="stylesheet" href="assets/css/login.css">
</head>

<body>

    <div class="login-container">

        <div class="login-box">

            <h1>ByteStream</h1>
            <h2>Welcome Back!</h2>

            <p>Sign in to continue exploring digital media.</p>

            <?php if ($error !== ""): ?>
                <div class="error-message">
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="login.php">

                <div class="form-group">
                    <label for="username">Username or Email</label>

                    <input
                        type="text"
                        id="username"
                        name="username"
                        placeholder="Enter username or email"
                        value="<?= htmlspecialchars($username) ?>"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="password">Password</label>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Enter your password"
                        required
                    >
                </div>

                <button type="submit">
                    Sign In
                </button>

            </form>

            <p class="register-link">
                Don't have an account?
                <a href="register.php">Create Account</a>
            </p>

        </div>

    </div>

</body>
</html>
