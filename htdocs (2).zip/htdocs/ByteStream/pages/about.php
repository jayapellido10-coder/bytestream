
<?php
session_start();

// Login protection
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

// Admin protection
if (($_SESSION["role"] ?? "") === "admin") {
    header("Location: ../admin/dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>About CCS | ByteStream</title>

    <link rel="stylesheet" href="../assets/css/dashboard.css">

    <style>
        .about-container {
            padding: 35px;
            max-width: 1100px;
            margin: auto;
            color: #eaf7ff;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #00eaff;
            text-decoration: none;
        }

        .back-link:hover {
            color: white;
        }

        .about-hero {
            text-align: center;
            padding: 65px 25px;
            background: linear-gradient(135deg, #102b4c, #211747);
            border: 1px solid #164e70;
            border-radius: 20px;
            box-shadow: 0 0 25px rgba(0, 220, 255, 0.12);
        }

        .hero-icon {
            font-size: 55px;
            margin-bottom: 15px;
        }

        .about-hero h1 {
            color: #00eaff;
            font-size: clamp(30px, 5vw, 42px);
            margin-bottom: 15px;
        }

        .about-hero p {
            max-width: 750px;
            margin: auto;
            line-height: 1.8;
            color: #c5d5e5;
        }

        .hero-tagline {
            color: #a78bfa !important;
            margin-bottom: 15px !important;
            font-weight: bold;
            letter-spacing: 2px;
        }

        .about-section {
            background: #101d35;
            border: 1px solid #164e70;
            border-radius: 15px;
            padding: 28px;
            margin-top: 25px;
            box-shadow: 0 0 15px rgba(0, 220, 255, 0.06);
        }

        .about-section h2 {
            color: #00eaff;
            margin-bottom: 15px;
        }

        .about-section p,
        .about-section li {
            line-height: 1.8;
            color: #c5d5e5;
        }

        .about-section ul {
            padding-left: 25px;
        }

        .about-section li {
            margin-bottom: 8px;
        }

        .about-values {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 18px;
            margin-top: 20px;
        }

        .value-card {
            background: #172b49;
            border: 1px solid #164e70;
            border-radius: 12px;
            padding: 22px;
            text-align: center;
            transition: 0.3s;
        }

        .value-card:hover {
            transform: translateY(-5px);
            border-color: #00eaff;
            box-shadow: 0 0 18px rgba(0, 220, 255, 0.15);
        }

        .value-icon {
            font-size: 32px;
            margin-bottom: 12px;
        }

        .value-card h3 {
            color: #00eaff;
            margin-bottom: 10px;
        }

        .mission-vision {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 20px;
            margin-top: 25px;
        }

        .mission-card {
            background: linear-gradient(135deg, #102b4c, #211747);
            border: 1px solid #164e70;
            border-radius: 15px;
            padding: 25px;
        }

        .mission-card h2 {
            color: #00eaff;
            margin-bottom: 15px;
        }

        .mission-card p {
            color: #c5d5e5;
            line-height: 1.8;
        }

        .about-footer {
            text-align: center;
            margin-top: 30px;
            padding: 25px;
            color: #91a8bd;
            border-top: 1px solid #164e70;
        }

        .about-footer span {
            color: #00eaff;
        }

        @media (max-width: 600px) {
            .about-container {
                padding: 18px;
            }

            .about-hero {
                padding: 40px 18px;
            }

            .about-section {
                padding: 20px;
            }
        }
    </style>
</head>

<body>

<div class="about-container">

    <a class="back-link" href="../dashboard.php">
        ← Back to Dashboard
    </a>

    <!-- HERO SECTION -->
    <section class="about-hero">

        <div class="hero-icon">💻</div>

        <p class="hero-tagline">EXPLORE • CREATE • INNOVATE</p>

        <h1>About CCS</h1>

        <p>
            Welcome to the College of Computer Studies (CCS).
            This section introduces the field of computing and
            technology and its role in developing digital skills,
            creativity, and innovation.
        </p>

    </section>

    <!-- ABOUT CCS -->
    <section class="about-section">

        <h2>About the College</h2>

        <p>
            The College of Computer Studies focuses on computing,
            information technology, and digital innovation.
            It encourages students to develop technical knowledge,
            problem-solving abilities, and practical skills that
            can be applied in the modern digital world.
        </p>

    </section>

    <!-- ABOUT BYTESTREAM -->
    <section class="about-section">

        <h2>About ByteStream</h2>

        <p>
            ByteStream is a digital media hub designed to provide
            users with a convenient platform for exploring videos,
            photos, and audio content in one place.
            It offers an organized media experience through
            different content categories and interactive features.
        </p>

        <p style="margin-top: 12px;">
            Users can browse media, play audio and videos,
            explore photos, save their favorite content,
            and revisit previously viewed media.
            Administrators can manage and organize uploaded
            content through the Admin Dashboard.
        </p>

    </section>

    <!-- MISSION AND VISION -->
    <div class="mission-vision">

        <section class="mission-card">

            <h2>🎯 Our Mission</h2>

            <p>
                To provide a convenient, organized, and accessible
                digital media platform where users can explore,
                enjoy, and manage different types of media content.
            </p>

        </section>

        <section class="mission-card">

            <h2>🚀 Our Vision</h2>

            <p>
                To become a user-friendly digital media hub that
                encourages creativity, accessibility, and meaningful
                digital experiences through technology.
            </p>

        </section>

    </div>

    <!-- OBJECTIVES -->
    <section class="about-section">

        <h2>Our Objectives</h2>

        <ul>
            <li>Provide an organized platform for digital media.</li>
            <li>Allow users to explore videos, photos, and audio.</li>
            <li>Make media content accessible through one website.</li>
            <li>Allow users to save and manage their favorite media.</li>
            <li>Provide a recently viewed feature for browsing history.</li>
            <li>Enable administrators to manage uploaded media.</li>
            <li>Promote creativity and digital content sharing.</li>
            <li>Provide a user-friendly browsing experience.</li>
        </ul>

    </section>

    <!-- CORE VALUES -->
    <section class="about-section">

        <h2>Our Core Values</h2>

        <div class="about-values">

            <div class="value-card">
                <div class="value-icon">💡</div>
                <h3>Innovation</h3>
                <p>
                    Encouraging new ideas and creative solutions
                    through technology.
                </p>
            </div>

            <div class="value-card">
                <div class="value-icon">🎨</div>
                <h3>Creativity</h3>
                <p>
                    Supporting digital expression, imagination,
                    and content discovery.
                </p>
            </div>

            <div class="value-card">
                <div class="value-icon">💻</div>
                <h3>Technology</h3>
                <p>
                    Using technology to improve digital
                    experiences and accessibility.
                </p>
            </div>

            <div class="value-card">
                <div class="value-icon">🌐</div>
                <h3>Accessibility</h3>
                <p>
                    Making digital content easy and convenient
                    to explore.
                </p>
            </div>

        </div>

    </section>

    <!-- FOOTER -->
    <footer class="about-footer">

        <p>
            <span>ByteStream</span> | Explore Your Digital World
        </p>

        <p>© <?= date("Y") ?> ByteStream. All Rights Reserved.</p>

    </footer>

</div>

</body>
</html>
