
<?php
session_start();

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../config/activity.php";

// User protection
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

if (($_SESSION["role"] ?? "") === "admin") {
    header("Location: ../admin/dashboard.php");
    exit;
}

$userId = (int) $_SESSION["user_id"];

if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION["csrf_token"];
$message = "";
$error = "";

function escapeAccount($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

// Get account information
$stmt = $pdo->prepare("
    SELECT username, email, role, created_at, password, profile_picture
    FROM users
    WHERE id = ?
");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) {
    session_destroy();
    header("Location: ../login.php");
    exit;
}

// Default avatar
$defaultAvatar = "../assets/images/default-avatar.png";

// Upload profile picture
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["upload_picture"])) {

    if (!hash_equals($csrfToken, $_POST["csrf_token"] ?? "")) {
        http_response_code(403);
        exit("Invalid security token.");
    }

    if (
        !isset($_FILES["profile_picture"]) ||
        $_FILES["profile_picture"]["error"] !== UPLOAD_ERR_OK
    ) {
        $error = "Please select a valid image.";
    } else {

        $file = $_FILES["profile_picture"];
        $maxSize = 5 * 1024 * 1024;

        if ($file["size"] > $maxSize) {
            $error = "Image must not exceed 5 MB.";
        } else {

            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($file["tmp_name"]);

            $allowedTypes = [
                "image/jpeg" => "jpg",
                "image/png" => "png",
                "image/webp" => "webp"
            ];

            if (!isset($allowedTypes[$mime])) {
                $error = "Only JPG, PNG, and WEBP images are allowed.";
            } else {

                $uploadDirectory = dirname(__DIR__) . "/uploads/profiles/";

                if (
                    !is_dir($uploadDirectory) &&
                    !mkdir($uploadDirectory, 0755, true)
                ) {
                    $error = "Unable to create the profile upload folder.";
                } else {

                    $newFileName = bin2hex(random_bytes(16))
                        . "." . $allowedTypes[$mime];

                    $destination = $uploadDirectory . $newFileName;

                    if (move_uploaded_file($file["tmp_name"], $destination)) {

                        $oldPicture = $user["profile_picture"];

                        try {
                            $update = $pdo->prepare("
                                UPDATE users
                                SET profile_picture = ?
                                WHERE id = ?
                            ");

                            $relativePath = "uploads/profiles/" . $newFileName;

                            $update->execute([$relativePath, $userId]);

                            logActivity(
                                $pdo,
                                $userId,
                                "Updated profile picture"
                            );

                            // Delete previous uploaded picture
                            if (!empty($oldPicture)) {
                                $oldPath = realpath(
                                    dirname(__DIR__) . "/" . $oldPicture
                                );

                                $profileDirectory = realpath($uploadDirectory);

                                if (
                                    $oldPath &&
                                    $profileDirectory &&
                                    strpos(
                                        $oldPath,
                                        $profileDirectory . DIRECTORY_SEPARATOR
                                    ) === 0 &&
                                    is_file($oldPath)
                                ) {
                                    unlink($oldPath);
                                }
                            }

                            header("Location: account.php?picture=updated");
                            exit;

                        } catch (PDOException $e) {
                            if (is_file($destination)) {
                                unlink($destination);
                            }

                            error_log("Profile picture update error: " . $e->getMessage());
                            $error = "Unable to update your profile picture.";
                        }

                    } else {
                        $error = "Unable to upload the image.";
                    }
                }
            }
        }
    }
}

// Change password
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["change_password"])) {

    if (!hash_equals($csrfToken, $_POST["csrf_token"] ?? "")) {
        http_response_code(403);
        exit("Invalid security token.");
    }

    $currentPassword = $_POST["current_password"] ?? "";
    $newPassword = $_POST["new_password"] ?? "";
    $confirmPassword = $_POST["confirm_password"] ?? "";

    if (
        $currentPassword === "" ||
        $newPassword === "" ||
        $confirmPassword === ""
    ) {
        $error = "Please complete all password fields.";

    } elseif (!password_verify($currentPassword, $user["password"])) {
        $error = "Your current password is incorrect.";

    } elseif (strlen($newPassword) < 8) {
        $error = "New password must contain at least 8 characters.";

    } elseif ($newPassword !== $confirmPassword) {
        $error = "New passwords do not match.";

    } else {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        $update = $pdo->prepare("
            UPDATE users
            SET password = ?
            WHERE id = ?
        ");

        $update->execute([$hashedPassword, $userId]);

        logActivity(
            $pdo,
            $userId,
            "Changed account password"
        );

        header("Location: account.php?password=updated");
        exit;
    }
}

// Success messages
if (isset($_GET["picture"]) && $_GET["picture"] === "updated") {
    $message = "Profile picture updated successfully!";
}

if (isset($_GET["password"]) && $_GET["password"] === "updated") {
    $message = "Password changed successfully!";
}

// Refresh account information
$stmt = $pdo->prepare("
    SELECT username, email, role, created_at, profile_picture
    FROM users
    WHERE id = ?
");
$stmt->execute([$userId]);
$user = $stmt->fetch();

$profilePicture = !empty($user["profile_picture"])
    ? "../" . $user["profile_picture"]
    : $defaultAvatar;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Account | ByteStream</title>

    <link rel="stylesheet" href="../assets/css/dashboard.css">

    <style>
        body {
            background: #071426;
            color: white;
        }

        .account-container {
            max-width: 950px;
            margin: auto;
            padding: 35px 20px;
        }

        .account-container h1 {
            color: #00eaff;
        }

        .account-card {
            background: #101d35;
            border: 1px solid #164e70;
            border-radius: 18px;
            padding: 28px;
            margin-top: 25px;
            box-shadow: 0 0 20px rgba(0,234,255,.08);
        }

        .profile-section {
            text-align: center;
        }

        .profile-picture {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #00eaff;
            box-shadow: 0 0 25px rgba(0,234,255,.4);
            background: #172b45;
        }

        .profile-section h2 {
            color: #00eaff;
            margin-bottom: 5px;
        }

        .profile-section p {
            color: #b8cce0;
        }

        .account-card h2 {
            color: #00eaff;
        }

        .account-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 18px;
            margin-top: 25px;
        }

        .info-item {
            background: #172b45;
            padding: 16px;
            border-radius: 10px;
            overflow-wrap: anywhere;
        }

        .info-item small {
            color: #8da9c4;
        }

        .info-item p {
            margin-bottom: 0;
        }

        .account-card input {
            width: 100%;
            box-sizing: border-box;
            padding: 13px;
            margin: 10px 0;
            background: #071426;
            color: white;
            border: 1px solid #164e70;
            border-radius: 8px;
        }

        .account-button {
            background: #00bce8;
            color: #071426;
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
        }

        .account-button:hover {
            background: #00eaff;
        }

        .success-message {
            color: #00eaff;
            background: #12334a;
            padding: 12px;
            border-radius: 8px;
        }

        .error-message {
            color: #ff7b86;
            background: #421d2a;
            padding: 12px;
            border-radius: 8px;
        }

        .back-link {
            color: #00eaff;
            text-decoration: none;
        }

        .upload-note {
            color: #91a8bd;
            font-size: 13px;
        }

        @media(max-width: 600px) {
            .account-container {
                padding: 20px 14px;
            }

            .account-card {
                padding: 20px;
            }
        }
    </style>
</head>

<body>

<div class="account-container">

    <h1>My Account</h1>
    <p>Manage your ByteStream profile and account settings.</p>

    <a href="../dashboard.php" class="back-link">
        ← Back to Dashboard
    </a>

    <?php if ($message): ?>
        <p class="success-message"><?= escapeAccount($message) ?></p>
    <?php endif; ?>

    <?php if ($error): ?>
        <p class="error-message"><?= escapeAccount($error) ?></p>
    <?php endif; ?>

    <!-- PROFILE PICTURE -->
    <section class="account-card profile-section">

        <img
            src="<?= escapeAccount($profilePicture) ?>"
            alt="Profile Picture"
            class="profile-picture"
            onerror="this.onerror=null;this.src='../assets/images/default-avatar.png';"
        >

        <h2><?= escapeAccount($user["username"]) ?></h2>

        <p><?= escapeAccount(ucfirst($user["role"])) ?> Account</p>

        <form method="POST" enctype="multipart/form-data">

            <input type="hidden" name="csrf_token"
                value="<?= escapeAccount($csrfToken) ?>">

            <label for="profile_picture">Choose Profile Picture</label>

            <input
                type="file"
                name="profile_picture"
                id="profile_picture"
                accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                required
            >

            <p class="upload-note">
                JPG, PNG, or WEBP. Maximum file size: 5 MB.
            </p>

            <button
                type="submit"
                name="upload_picture"
                class="account-button"
            >
                Upload / Change Picture
            </button>

        </form>

    </section>

    <!-- ACCOUNT INFORMATION -->
    <section class="account-card">

        <h2>Account Information</h2>

        <div class="account-info">

            <div class="info-item">
                <small>Username</small>
                <p><?= escapeAccount($user["username"]) ?></p>
            </div>

            <div class="info-item">
                <small>Email Address</small>
                <p><?= escapeAccount($user["email"]) ?></p>
            </div>

            <div class="info-item">
                <small>Account Role</small>
                <p><?= escapeAccount(ucfirst($user["role"])) ?></p>
            </div>

            <div class="info-item">
                <small>Account Created</small>
                <p><?= escapeAccount(date("M d, Y", strtotime($user["created_at"]))) ?></p>
            </div>

        </div>

    </section>

    <!-- CHANGE PASSWORD -->
    <section class="account-card">

        <h2>Change Password</h2>

        <form method="POST">

            <input type="hidden" name="csrf_token"
                value="<?= escapeAccount($csrfToken) ?>">

            <label>Current Password</label>
            <input
                type="password"
                name="current_password"
                placeholder="Enter current password"
                autocomplete="current-password"
                required
            >

            <label>New Password</label>
            <input
                type="password"
                name="new_password"
                placeholder="Enter new password (minimum 8 characters)"
                minlength="8"
                autocomplete="new-password"
                required
            >

            <label>Confirm New Password</label>
            <input
                type="password"
                name="confirm_password"
                placeholder="Confirm new password"
                minlength="8"
                autocomplete="new-password"
                required
            >

            <button
                type="submit"
                name="change_password"
                class="account-button"
            >
                Change Password
            </button>

        </form>

    </section>

</div>

</body>
</html>
