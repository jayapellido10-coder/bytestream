
<?php
session_start();

require_once __DIR__ . "/../config/database.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

if (($_SESSION["role"] ?? "") === "admin") {
    header("Location: ../admin/dashboard.php");
    exit;
}

if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$userId = (int) $_SESSION["user_id"];
$message = "";

// Search, category and sorting filters
$search = trim($_GET["search"] ?? "");
$categoryId = $_GET["category"] ?? "";
$sort = $_GET["sort"] ?? "newest";

if (!in_array($sort, ["newest", "oldest"], true)) {
    $sort = "newest";
}

// Add to favorites
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["add_favorite"])) {

    if (!hash_equals($_SESSION["csrf_token"], $_POST["csrf_token"] ?? "")) {
        http_response_code(403);
        exit("Invalid request.");
    }

    $mediaId = filter_var(
        $_POST["media_id"] ?? null,
        FILTER_VALIDATE_INT
    );

    if ($mediaId) {
        $check = $pdo->prepare("
            SELECT id FROM media
            WHERE id = ? AND media_type = 'video'
        ");
        $check->execute([$mediaId]);

        if ($check->fetch()) {
            $favorite = $pdo->prepare("
                INSERT IGNORE INTO favorites (user_id, media_id)
                VALUES (?, ?)
            ");
            $favorite->execute([$userId, $mediaId]);

            if ($favorite->rowCount() > 0) {
                $message = "Video added to your favorites!";
            } else {
                $message = "This video is already in your favorites.";
            }
        }
    }
}

// Get video categories
$categoryStmt = $pdo->prepare("
    SELECT id, name
    FROM categories
    WHERE media_type = 'video'
    ORDER BY name ASC
");
$categoryStmt->execute();
$categories = $categoryStmt->fetchAll();

// Build video query
$sql = "
    SELECT
        m.id,
        m.title,
        m.description,
        m.file_name,
        m.category_id,
        m.created_at,
        c.name AS category_name,
        EXISTS (
            SELECT 1 FROM favorites f
            WHERE f.user_id = ? AND f.media_id = m.id
        ) AS is_favorite
    FROM media m
    LEFT JOIN categories c ON m.category_id = c.id
    WHERE m.media_type = 'video'
";

$params = [$userId];

// Search filter
if ($search !== "") {
    $sql .= " AND (m.title LIKE ? OR m.description LIKE ?)";
    $keyword = "%" . $search . "%";
    $params[] = $keyword;
    $params[] = $keyword;
}

// Category filter
if ($categoryId !== "") {
    $validCategoryId = filter_var(
        $categoryId,
        FILTER_VALIDATE_INT
    );

    if ($validCategoryId) {
        $sql .= " AND m.category_id = ?";
        $params[] = $validCategoryId;
    } else {
        $categoryId = "";
    }
}

// Sorting
$sql .= $sort === "oldest"
    ? " ORDER BY m.created_at ASC"
    : " ORDER BY m.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$videos = $stmt->fetchAll();

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Videos | ByteStream</title>

    <link rel="stylesheet" href="../assets/css/dashboard.css">

    <style>
        .videos-container {
            padding: 30px;
            color: white;
        }

        .videos-container h1 {
            color: #00eaff;
        }

        .videos-container a {
            color: #00eaff;
        }

        .video-filters {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 25px;
            align-items: center;
        }

        .video-filters input,
        .video-filters select {
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #164e70;
            background: #101d35;
            color: white;
            min-width: 160px;
        }

        .video-filters input {
            flex: 1;
        }

        .filter-button {
            padding: 12px 18px;
            border: none;
            border-radius: 8px;
            background: #00bce8;
            color: #071426;
            cursor: pointer;
            font-weight: bold;
        }

        .clear-button {
            text-decoration: none;
            padding: 10px;
        }

        .videos-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }

        .video-card {
            background: #101d35;
            border: 1px solid #164e70;
            border-radius: 15px;
            padding: 18px;
            min-width: 0;
        }

        .video-card video {
            width: 100%;
            border-radius: 10px;
            background: black;
        }

        .video-card h3 {
            color: #00eaff;
            margin-top: 15px;
        }

        .video-card p {
            color: #c5d5e5;
        }

        .video-category {
            color: #a78bfa !important;
            font-size: 13px;
        }

        .video-date {
            display: block;
            color: #91a8bd;
            margin-top: 12px;
            font-size: 12px;
        }

        .favorite-button {
            background: #6c3ce7;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 10px 15px;
            margin-top: 15px;
            cursor: pointer;
        }

        .favorite-button:hover {
            background: #885fff;
        }

        .favorite-button:disabled {
            background: #42516b;
            cursor: not-allowed;
        }

        .success-message {
            color: #00eaff;
            margin-top: 20px;
        }

        .empty-message {
            color: #c5d5e5;
            margin-top: 30px;
        }

        @media (max-width: 600px) {
            .videos-container {
                padding: 18px;
            }

            .video-filters {
                flex-direction: column;
                align-items: stretch;
            }

            .video-filters input,
            .video-filters select {
                width: 100%;
                box-sizing: border-box;
            }
        }
    </style>
</head>

<body>

<div class="videos-container">

    <h1>ByteStream Videos</h1>
    <p>Explore and watch videos uploaded by our Admin.</p>

    <a href="../dashboard.php">← Back to Dashboard</a>

    <!-- SEARCH AND FILTER -->
    <form method="GET" class="video-filters">

        <input
            type="search"
            name="search"
            placeholder="Search video title or description..."
            value="<?= e($search) ?>"
        >

        <select name="category">
            <option value="">All Categories</option>

            <?php foreach ($categories as $category): ?>
                <option
                    value="<?= (int)$category["id"] ?>"
                    <?= (string)$categoryId === (string)$category["id"] ? "selected" : "" ?>
                >
                    <?= e($category["name"]) ?>
                </option>
            <?php endforeach; ?>

        </select>

        <select name="sort">
            <option value="newest" <?= $sort === "newest" ? "selected" : "" ?>>
                Newest First
            </option>

            <option value="oldest" <?= $sort === "oldest" ? "selected" : "" ?>>
                Oldest First
            </option>
        </select>

        <button type="submit" class="filter-button">
            Search
        </button>

        <a href="videos.php" class="clear-button">
            Clear Filters
        </a>

    </form>

    <?php if ($message): ?>
        <p class="success-message"><?= e($message) ?></p>
    <?php endif; ?>

    <?php if (empty($videos)): ?>

        <p class="empty-message">
            No videos found. Try another search or category.
        </p>

    <?php else: ?>

        <div class="videos-grid">

            <?php foreach ($videos as $video): ?>

                <article class="video-card">

                    <video
                        controls
                        preload="metadata"
                        data-media-id="<?= (int)$video["id"] ?>"
                    >
                        <source
                            src="../uploads/videos/<?= rawurlencode(basename($video["file_name"])) ?>"
                        >
                        Your browser does not support video playback.
                    </video>

                    <h3><?= e($video["title"]) ?></h3>

                    <p><?= nl2br(e($video["description"])) ?></p>

                    <p class="video-category">
                        Category:
                        <?= e($video["category_name"] ?? "Uncategorized") ?>
                    </p>

                    <span class="video-date">
                        Uploaded:
                        <?= e(date("M d, Y", strtotime($video["created_at"]))) ?>
                    </span>

                    <form method="POST">

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= e($_SESSION["csrf_token"]) ?>"
                        >

                        <input
                            type="hidden"
                            name="media_id"
                            value="<?= (int)$video["id"] ?>"
                        >

                        <button
                            type="submit"
                            name="add_favorite"
                            class="favorite-button"
                            <?= $video["is_favorite"] ? "disabled" : "" ?>
                        >
                            <?= $video["is_favorite"]
                                ? "♥ Added to Favorites"
                                : "♡ Add to Favorites" ?>
                        </button>

                    </form>

                </article>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

</div>

<script>
const csrfToken = <?= json_encode($_SESSION["csrf_token"]) ?>;

document.querySelectorAll("video[data-media-id]").forEach(video => {

    video.addEventListener("play", async function () {

        if (video.dataset.tracked === "true") return;

        video.dataset.tracked = "true";

        const formData = new FormData();
        formData.append("media_id", video.dataset.mediaId);

        try {
            const response = await fetch("track-view.php", {
                method: "POST",
                headers: {
                    "X-CSRF-Token": csrfToken
                },
                body: formData
            });

            if (!response.ok) {
                video.dataset.tracked = "false";
            }

        } catch (error) {
            video.dataset.tracked = "false";
        }

    });

});
</script>

</body>
</html>
