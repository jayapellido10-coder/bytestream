<?php
session_start();

require_once "../config/database.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

if ($_SESSION["role"] === "admin") {
    header("Location: ../admin/dashboard.php");
    exit;
}

$search = trim($_GET["q"] ?? "");
$results = [];

if ($search !== "") {
    $keyword = "%" . $search . "%";

    $stmt = $pdo->prepare("
        SELECT
            m.id,
            m.title,
            m.description,
            m.file_name,
            m.media_type,
            m.created_at,
            c.name AS category_name
        FROM media m
        LEFT JOIN categories c ON m.category_id = c.id
        WHERE m.title LIKE ?
           OR m.description LIKE ?
           OR c.name LIKE ?
        ORDER BY m.created_at DESC
    ");

    $stmt->execute([$keyword, $keyword, $keyword]);
    $results = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Search | ByteStream</title>

    <link rel="stylesheet" href="../assets/css/dashboard.css">

    <style>
        body {
            background: #07111f;
            color: white;
            font-family: Arial, sans-serif;
        }

        .search-container {
            max-width: 1100px;
            margin: 40px auto;
            padding: 25px;
        }

        .search-container h1 {
            color: #00eaff;
        }

        .search-form {
            display: flex;
            gap: 10px;
            margin: 25px 0;
        }

        .search-form input {
            flex: 1;
            min-width: 0;
            padding: 14px;
            border: 1px solid #00eaff;
            border-radius: 8px;
            background: #101d31;
            color: white;
        }

        .search-form button {
            padding: 14px 22px;
            border: none;
            border-radius: 8px;
            background: #00dff5;
            color: #07111f;
            font-weight: bold;
            cursor: pointer;
        }

        .results-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
            gap: 20px;
        }

        .result-card {
            padding: 18px;
            background: #101d31;
            border: 1px solid rgba(0, 234, 255, .3);
            border-radius: 12px;
        }

        .result-card h3 {
            color: #00eaff;
        }

        .result-card video,
        .result-card img,
        .result-card audio {
            width: 100%;
            margin-top: 10px;
            border-radius: 8px;
        }

        .result-type {
            color: #b69aff;
            text-transform: capitalize;
        }

        .back-link {
            display: inline-block;
            margin-top: 25px;
            color: #00eaff;
            text-decoration: none;
        }

        @media (max-width: 500px) {
            .search-form {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>

<div class="search-container">

    <h1>Search ByteStream</h1>
    <p>Find your favorite videos, photos, and audio.</p>

    <form method="GET" class="search-form">
        <input
            type="search"
            name="q"
            placeholder="Search videos, photos, or audio..."
            value="<?= htmlspecialchars($search) ?>"
            required
        >

        <button type="submit">Search</button>
    </form>

    <?php if ($search !== ""): ?>

        <h2>
            Search Results for:
            <?= htmlspecialchars($search) ?>
        </h2>

        <?php if (empty($results)): ?>

            <p>No media found. Try another keyword.</p>

        <?php else: ?>

            <div class="results-grid">

                <?php foreach ($results as $item): ?>

                    <?php
                    $folder = [
                        "video" => "videos",
                        "photo" => "photos",
                        "audio" => "audio"
                    ][$item["media_type"]];

                    $filePath = "../uploads/" . $folder . "/" .
                                rawurlencode($item["file_name"]);
                    ?>

                    <div class="result-card">

                        <h3>
                            <?= htmlspecialchars($item["title"]) ?>
                        </h3>

                        <p class="result-type">
                            <?= htmlspecialchars($item["media_type"]) ?>
                        </p>

                        <p>
                            <?= htmlspecialchars($item["description"] ?? "") ?>
                        </p>

                        <?php if ($item["media_type"] === "video"): ?>

                            <video controls>
                                <source src="<?= htmlspecialchars($filePath) ?>">
                            </video>

                        <?php elseif ($item["media_type"] === "photo"): ?>

                            <img
                                src="<?= htmlspecialchars($filePath) ?>"
                                alt="<?= htmlspecialchars($item["title"]) ?>"
                            >

                        <?php elseif ($item["media_type"] === "audio"): ?>

                            <audio controls>
                                <source src="<?= htmlspecialchars($filePath) ?>">
                            </audio>

                        <?php endif; ?>

                    </div>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    <?php endif; ?>

    <a href="../dashboard.php" class="back-link">
        ← Back to Dashboard
    </a>

</div>

</body>
</html>