
<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

if (($_SESSION["role"] ?? "") === "admin") {
    header("Location: ../admin/dashboard.php");
    exit;
}

require_once __DIR__ . "/../config/database.php";

$userId = (int) $_SESSION["user_id"];
$username = $_SESSION["username"] ?? "User";

// Get media counts
$videoCount = (int) $pdo->query(
    "SELECT COUNT(*) FROM media WHERE media_type = 'video'"
)->fetchColumn();

$photoCount = (int) $pdo->query(
    "SELECT COUNT(*) FROM media WHERE media_type = 'photo'"
)->fetchColumn();

$audioCount = (int) $pdo->query(
    "SELECT COUNT(*) FROM media WHERE media_type = 'audio'"
)->fetchColumn();

// Get latest uploaded media
$stmt = $pdo->query("
    SELECT
        m.*,
        c.name AS category_name
    FROM media m
    LEFT JOIN categories c ON m.category_id = c.id
    ORDER BY m.created_at DESC
    LIMIT 6
");

$latestMedia = $stmt->fetchAll();

// Get user's favorite count
$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM favorites
    WHERE user_id = ?
");
$stmt->execute([$userId]);
$favoriteCount = (int) $stmt->fetchColumn();

// Get recently viewed count
$stmt = $pdo->prepare("
    SELECT COUNT(DISTINCT media_id)
    FROM viewing_history
    WHERE user_id = ?
");
$stmt->execute([$userId]);
$recentCount = (int) $stmt->fetchColumn();

// Escape output
function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Home | ByteStream</title>

    <link rel="stylesheet" href="../assets/css/dashboard.css">

    <style>
        .home-container {
            max-width: 1200px;
            margin: auto;
            padding: 30px;
            color: #eaf7ff;
        }

        .welcome-banner {
            padding: 45px;
            border-radius: 20px;
            background: linear-gradient(120deg, #102b4c, #211747);
            border: 1px solid #164e70;
            box-shadow: 0 0 25px rgba(0, 220, 255, .12);
            margin-bottom: 30px;
        }

        .welcome-banner h1 {
            font-size: clamp(28px, 5vw, 40px);
            color: #00eaff;
            margin-bottom: 12px;
        }

        .welcome-banner p {
            color: #c5d5e5;
            line-height: 1.8;
            max-width: 700px;
        }

        .home-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 12px 22px;
            border-radius: 8px;
            background: #00cfe8;
            color: #07172b;
            text-decoration: none;
            font-weight: bold;
            transition: .3s;
        }

        .home-btn:hover {
            background: #ffffff;
            transform: translateY(-3px);
        }

        .section-title {
            color: #00eaff;
            margin: 30px 0 18px;
            font-size: 24px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
            gap: 18px;
        }

        .stat-card {
            padding: 22px;
            border-radius: 14px;
            background: #101d35;
            border: 1px solid #164e70;
            text-align: center;
        }

        .stat-card .stat-icon {
            font-size: 30px;
            margin-bottom: 10px;
        }

        .stat-card h2 {
            color: #00eaff;
            font-size: 28px;
            margin-bottom: 5px;
        }

        .stat-card p {
            color: #b7c9dc;
        }

        .quick-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 18px;
        }

        .quick-card {
            display: block;
            text-decoration: none;
            color: #eaf7ff;
            padding: 24px;
            border-radius: 14px;
            background: #101d35;
            border: 1px solid #164e70;
            transition: .3s;
        }

        .quick-card:hover {
            transform: translateY(-5px);
            border-color: #00eaff;
            box-shadow: 0 0 18px rgba(0, 220, 255, .15);
        }

        .quick-card .quick-icon {
            font-size: 32px;
            margin-bottom: 12px;
        }

        .quick-card h3 {
            color: #00eaff;
            margin-bottom: 8px;
        }

        .quick-card p {
            color: #b7c9dc;
            line-height: 1.6;
            font-size: 14px;
        }

        .media-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
            gap: 20px;
        }

        .media-card {
            background: #101d35;
            border: 1px solid #164e70;
            border-radius: 14px;
            overflow: hidden;
            transition: .3s;
        }

        .media-card:hover {
            transform: translateY(-5px);
            border-color: #00eaff;
        }

        .media-preview {
            width: 100%;
            height: 170px;
            object-fit: cover;
            background: #080f20;
            display: block;
        }

        .media-info {
            padding: 17px;
        }

        .media-info h3 {
            color: #00eaff;
            margin-bottom: 8px;
            overflow-wrap: anywhere;
        }

        .media-info p {
            color: #b7c9dc;
            font-size: 13px;
            line-height: 1.6;
        }

        .media-type {
            display: inline-block;
            margin-top: 10px;
            padding: 5px 10px;
            border-radius: 20px;
            background: #172b49;
            color: #00eaff;
            font-size: 12px;
        }

        .view-link {
            display: inline-block;
            margin-top: 13px;
            color: #00eaff;
            text-decoration: none;
            font-weight: bold;
        }

        .empty-state {
            background: #101d35;
            border: 1px dashed #164e70;
            border-radius: 14px;
            padding: 35px;
            text-align: center;
            color: #b7c9dc;
            grid-column: 1 / -1;
        }

        .home-footer {
            text-align: center;
            padding: 25px 10px;
            margin-top: 35px;
            border-top: 1px solid #164e70;
            color: #91a8bd;
        }

        .home-footer span {
            color: #00eaff;
        }

        @media (max-width: 600px) {
            .home-container {
                padding: 18px;
            }

            .welcome-banner {
                padding: 28px 20px;
            }
        }
    </style>
</head>

<body>

<div class="home-container">

    <!-- WELCOME BANNER -->
    <section class="welcome-banner">

        <h1>Welcome to ByteStream, <?= e($username) ?>! 👋</h1>

        <p>
            Explore your digital world in one place.
            Discover videos, beautiful photos, and audio content.
            Save your favorite media and enjoy a convenient
            digital browsing experience.
        </p>

        <a href="../search.php" class="home-btn">
            🔍 Explore Media
        </a>

    </section>

    <!-- MEDIA STATISTICS -->
    <h2 class="section-title">Your Media Hub</h2>

    <div class="stats-grid">

        <div class="stat-card">
            <div class="stat-icon">🎬</div>
            <h2><?= $videoCount ?></h2>
            <p>Videos Available</p>
        </div>

        <div class="stat-card">
            <div class="stat-icon">🖼️</div>
            <h2><?= $photoCount ?></h2>
            <p>Photos Available</p>
        </div>

        <div class="stat-card">
            <div class="stat-icon">🎵</div>
            <h2><?= $audioCount ?></h2>
            <p>Audio Available</p>
        </div>

        <div class="stat-card">
            <div class="stat-icon">❤️</div>
            <h2><?= $favoriteCount ?></h2>
            <p>My Favorites</p>
        </div>

        <div class="stat-card">
            <div class="stat-icon">🕒</div>
            <h2><?= $recentCount ?></h2>
            <p>Recently Viewed</p>
        </div>

    </div>

    <!-- QUICK ACCESS -->
    <h2 class="section-title">Quick Access</h2>

    <div class="quick-grid">

        <a href="videos.php" class="quick-card">
            <div class="quick-icon">🎬</div>
            <h3>Videos</h3>
            <p>Watch and explore available videos.</p>
        </a>

        <a href="gallery.php" class="quick-card">
            <div class="quick-icon">🖼️</div>
            <h3>Photo Gallery</h3>
            <p>Browse different photos and images.</p>
        </a>

        <a href="audio.php" class="quick-card">
            <div class="quick-icon">🎧</div>
            <h3>MP3 / Audio</h3>
            <p>Listen to available audio content.</p>
        </a>

        <a href="favorites.php" class="quick-card">
            <div class="quick-icon">❤️</div>
            <h3>My Favorites</h3>
            <p>View your saved favorite media.</p>
        </a>

        <a href="recently-viewed.php" class="quick-card">
            <div class="quick-icon">🕒</div>
            <h3>Recently Viewed</h3>
            <p>Continue exploring your viewing history.</p>
        </a>

        <a href="account.php" class="quick-card">
            <div class="quick-icon">👤</div>
            <h3>My Account</h3>
            <p>View your profile and account settings.</p>
        </a>

    </div>

    <!-- LATEST MEDIA -->
    <h2 class="section-title">Latest Uploaded Media</h2>

    <div class="media-grid">

        <?php if (empty($latestMedia)): ?>

            <div class="empty-state">
                <h3>No Media Available Yet</h3>
                <p>New videos, photos, and audio will appear here once uploaded.</p>
            </div>

        <?php else: ?>

            <?php foreach ($latestMedia as $media): ?>

                <?php
                    $type = $media["media_type"];
                    $file = "../uploads/" . $type . "/" . rawurlencode($media["file_name"]);

                    if ($type === "video") {
                        $destination = "videos.php";
                    } elseif ($type === "photo") {
                        $destination = "gallery.php";
                    } else {
                        $destination = "audio.php";
                    }
                ?>

                <article class="media-card">

                    <?php if ($type === "photo"): ?>

                        <img
                            src="<?= e($file) ?>"
                            alt="<?= e($media["title"]) ?>"
                            class="media-preview"
                            loading="lazy"
                        >

                    <?php elseif ($type === "video"): ?>

                        <video
                            class="media-preview"
                            controls
                            preload="metadata"
                        >
                            <source src="<?= e($file) ?>">
                            Your browser does not support video playback.
                        </video>

                    <?php else: ?>

                        <div class="media-preview"
                             style="display:flex;align-items:center;justify-content:center;font-size:55px;">
                            🎵
                        </div>

                    <?php endif; ?>

                    <div class="media-info">

                        <h3><?= e($media["title"]) ?></h3>

                        <p>
                            <?= e($media["description"] ?: "No description available.") ?>
                        </p>

                        <span class="media-type">
                            <?= e(ucfirst($type)) ?>
                        </span>

                        <?php if (!empty($media["category_name"])): ?>
                            <p style="margin-top:8px;">
                                Category: <?= e($media["category_name"]) ?>
                            </p>
                        <?php endif; ?>

                        <a href="<?= e($destination) ?>" class="view-link">
                            Explore <?= e(ucfirst($type)) ?> →
                        </a>

                    </div>

                </article>

            <?php endforeach; ?>

        <?php endif; ?>

    </div>

    <!-- FOOTER -->
    <footer class="home-footer">

        <p>
            <span>ByteStream</span> | Explore Your Digital World
        </p>

        <p>© <?= date("Y") ?> ByteStream. All Rights Reserved.</p>

    </footer>

</div>

</body>
</html>
