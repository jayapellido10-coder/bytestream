
<?php
session_start();

require_once __DIR__ . "/../config/database.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

if (($_SESSION["role"] ?? "") === "admin") {
    header("Location: ../admin/dashboard.php");
    exit;
}

if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$userId = (int) $_SESSION["user_id"];
$message = "";

// Search and filters
$search = trim($_GET["search"] ?? "");
$categoryId = $_GET["category"] ?? "";
$sort = $_GET["sort"] ?? "newest";

if (!in_array($sort, ["newest", "oldest"], true)) {
    $sort = "newest";
}

// Add photo to favorites
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["add_favorite"])) {

    if (!hash_equals($_SESSION["csrf_token"], $_POST["csrf_token"] ?? "")) {
        http_response_code(403);
        exit("Invalid request.");
    }

    $mediaId = filter_var(
        $_POST["media_id"] ?? null,
        FILTER_VALIDATE_INT
    );

    if ($mediaId) {
        $check = $pdo->prepare("
            SELECT id FROM media
            WHERE id = ? AND media_type = 'photo'
        ");
        $check->execute([$mediaId]);

        if ($check->fetch()) {
            $favorite = $pdo->prepare("
                INSERT IGNORE INTO favorites (user_id, media_id)
                VALUES (?, ?)
            ");
            $favorite->execute([$userId, $mediaId]);

            if ($favorite->rowCount() > 0) {
                $message = "Photo added to your favorites!";
            } else {
                $message = "This photo is already in your favorites.";
            }
        }
    }
}

// Get photo categories
$categoryStmt = $pdo->prepare("
    SELECT id, name
    FROM categories
    WHERE media_type = 'photo'
    ORDER BY name ASC
");
$categoryStmt->execute();
$categories = $categoryStmt->fetchAll();

// Build photo query
$sql = "
    SELECT
        m.id,
        m.title,
        m.description,
        m.file_name,
        m.category_id,
        m.created_at,
        c.name AS category_name,
        EXISTS (
            SELECT 1 FROM favorites f
            WHERE f.user_id = ? AND f.media_id = m.id
        ) AS is_favorite
    FROM media m
    LEFT JOIN categories c ON m.category_id = c.id
    WHERE m.media_type = 'photo'
";

$params = [$userId];

// Search filter
if ($search !== "") {
    $sql .= " AND (m.title LIKE ? OR m.description LIKE ?)";
    $keyword = "%" . $search . "%";
    $params[] = $keyword;
    $params[] = $keyword;
}

// Category filter
if ($categoryId !== "") {
    $validCategoryId = filter_var(
        $categoryId,
        FILTER_VALIDATE_INT
    );

    if ($validCategoryId) {
        $sql .= " AND m.category_id = ?";
        $params[] = $validCategoryId;
    } else {
        $categoryId = "";
    }
}

// Sorting
$sql .= $sort === "oldest"
    ? " ORDER BY m.created_at ASC"
    : " ORDER BY m.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$photos = $stmt->fetchAll();

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Photo Gallery | ByteStream</title>

    <link rel="stylesheet" href="../assets/css/dashboard.css">

    <style>
        .gallery-container {
            padding: 30px;
            color: white;
        }

        .gallery-container h1 {
            color: #00eaff;
        }

        .gallery-container a {
            color: #00eaff;
        }

        .gallery-filters {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 25px;
            align-items: center;
        }

        .gallery-filters input,
        .gallery-filters select {
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #164e70;
            background: #101d35;
            color: white;
            min-width: 160px;
        }

        .gallery-filters input {
            flex: 1;
        }

        .filter-button {
            padding: 12px 18px;
            border: none;
            border-radius: 8px;
            background: #00bce8;
            color: #071426;
            cursor: pointer;
            font-weight: bold;
        }

        .clear-button {
            text-decoration: none;
            padding: 10px;
        }

        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
            gap: 22px;
            margin-top: 30px;
        }

        .photo-card {
            background: #101d35;
            border: 1px solid #164e70;
            border-radius: 15px;
            padding: 12px;
            overflow: hidden;
        }

        .photo-card img {
            width: 100%;
            height: 220px;
            object-fit: cover;
            border-radius: 10px;
            display: block;
            cursor: pointer;
            transition: transform .3s ease;
        }

        .photo-card img:hover {
            transform: scale(1.03);
        }

        .photo-card h3 {
            color: #00eaff;
            margin: 14px 5px 8px;
        }

        .photo-card p {
            color: #c5d5e5;
            margin: 5px;
        }

        .photo-category {
            color: #a78bfa !important;
            font-size: 13px;
        }

        .photo-date {
            display: block;
            color: #91a8bd;
            font-size: 12px;
            margin: 10px 5px;
        }

        .favorite-button {
            background: #6c3ce7;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 10px 15px;
            cursor: pointer;
            margin: 8px 5px;
        }

        .favorite-button:hover {
            background: #885fff;
        }

        .favorite-button:disabled {
            background: #42516b;
            cursor: not-allowed;
        }

        .success-message {
            color: #00eaff;
            margin-top: 20px;
        }

        .empty-message {
            color: #c5d5e5;
            margin-top: 30px;
        }

        .image-viewer {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, .94);
            justify-content: center;
            align-items: center;
            padding: 20px;
            z-index: 9999;
        }

        .image-viewer img {
            max-width: 90%;
            max-height: 85vh;
            object-fit: contain;
            border-radius: 12px;
        }

        .image-viewer button {
            position: absolute;
            top: 20px;
            right: 30px;
            background: transparent;
            border: none;
            color: white;
            font-size: 38px;
            cursor: pointer;
        }

        @media (max-width: 600px) {
            .gallery-container {
                padding: 18px;
            }

            .gallery-filters {
                flex-direction: column;
                align-items: stretch;
            }

            .gallery-filters input,
            .gallery-filters select {
                width: 100%;
                box-sizing: border-box;
            }
        }
    </style>
</head>

<body>

<div class="gallery-container">

    <h1>ByteStream Photo Gallery</h1>
    <p>Discover photos uploaded by our Admin.</p>

    <a href="../dashboard.php">← Back to Dashboard</a>

    <!-- SEARCH AND FILTER -->
    <form method="GET" class="gallery-filters">

        <input
            type="search"
            name="search"
            placeholder="Search photo title or description..."
            value="<?= e($search) ?>"
        >

        <select name="category">
            <option value="">All Categories</option>

            <?php foreach ($categories as $category): ?>
                <option
                    value="<?= (int)$category["id"] ?>"
                    <?= (string)$categoryId === (string)$category["id"] ? "selected" : "" ?>
                >
                    <?= e($category["name"]) ?>
                </option>
            <?php endforeach; ?>

        </select>

        <select name="sort">
            <option value="newest" <?= $sort === "newest" ? "selected" : "" ?>>
                Newest First
            </option>

            <option value="oldest" <?= $sort === "oldest" ? "selected" : "" ?>>
                Oldest First
            </option>
        </select>

        <button type="submit" class="filter-button">
            Search
        </button>

        <a href="gallery.php" class="clear-button">
            Clear Filters
        </a>

    </form>

    <?php if ($message): ?>
        <p class="success-message"><?= e($message) ?></p>
    <?php endif; ?>

    <?php if (empty($photos)): ?>

        <p class="empty-message">
            No photos found. Try another search or category.
        </p>

    <?php else: ?>

        <div class="gallery-grid">

            <?php foreach ($photos as $photo): ?>

                <article class="photo-card">

                    <img
                        src="../uploads/photos/<?= rawurlencode(basename($photo["file_name"])) ?>"
                        alt="<?= e($photo["title"]) ?>"
                        data-media-id="<?= (int)$photo["id"] ?>"
                        onclick="openImage(this)"
                        loading="lazy"
                    >

                    <h3><?= e($photo["title"]) ?></h3>

                    <p><?= nl2br(e($photo["description"])) ?></p>

                    <p class="photo-category">
                        Category:
                        <?= e($photo["category_name"] ?? "Uncategorized") ?>
                    </p>

                    <span class="photo-date">
                        Uploaded:
                        <?= e(date("M d, Y", strtotime($photo["created_at"]))) ?>
                    </span>

                    <form method="POST">

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= e($_SESSION["csrf_token"]) ?>"
                        >

                        <input
                            type="hidden"
                            name="media_id"
                            value="<?= (int)$photo["id"] ?>"
                        >

                        <button
                            type="submit"
                            name="add_favorite"
                            class="favorite-button"
                            <?= $photo["is_favorite"] ? "disabled" : "" ?>
                        >
                            <?= $photo["is_favorite"]
                                ? "♥ Added to Favorites"
                                : "♡ Add to Favorites" ?>
                        </button>

                    </form>

                </article>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

</div>

<!-- IMAGE VIEWER -->
<div
    class="image-viewer"
    id="imageViewer"
    onclick="closeImage()"
>
    <button type="button" aria-label="Close image">&times;</button>
    <img id="viewerImage" src="" alt="Expanded photo">
</div>

<script>
const csrfToken = <?= json_encode($_SESSION["csrf_token"]) ?>;

function openImage(element) {
    const viewer = document.getElementById("imageViewer");
    const viewerImage = document.getElementById("viewerImage");

    viewerImage.src = element.src;
    viewer.style.display = "flex";

    if (element.dataset.tracked !== "true") {
        element.dataset.tracked = "true";

        const formData = new FormData();
        formData.append("media_id", element.dataset.mediaId);

        fetch("track-view.php", {
            method: "POST",
            headers: {
                "X-CSRF-Token": csrfToken
            },
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                element.dataset.tracked = "false";
            }
        })
        .catch(() => {
            element.dataset.tracked = "false";
        });
    }
}

function closeImage() {
    document.getElementById("imageViewer").style.display = "none";
    document.getElementById("viewerImage").src = "";
}

document.addEventListener("keydown", function(event) {
    if (event.key === "Escape") {
        closeImage();
    }
});
</script>

</body>
</html>
