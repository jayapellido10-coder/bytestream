
<?php
session_start();

require_once __DIR__ . "/../config/database.php";

// Login protection
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

// Admin protection
if (($_SESSION["role"] ?? "") === "admin") {
    header("Location: ../admin/dashboard.php");
    exit;
}

if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$userId = (int) $_SESSION["user_id"];
$message = "";

// Clear viewing history
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["clear_history"])) {

    if (!hash_equals($_SESSION["csrf_token"], $_POST["csrf_token"] ?? "")) {
        http_response_code(403);
        exit("Invalid request.");
    }

    $delete = $pdo->prepare("
        DELETE FROM viewing_history
        WHERE user_id = ?
    ");

    $delete->execute([$userId]);

    $message = "Your viewing history has been cleared.";
}

// Search and filters
$search = trim($_GET["search"] ?? "");
$type = $_GET["type"] ?? "all";
$sort = $_GET["sort"] ?? "newest";

$allowedTypes = ["all", "video", "photo", "audio"];

if (!in_array($type, $allowedTypes, true)) {
    $type = "all";
}

if (!in_array($sort, ["newest", "oldest"], true)) {
    $sort = "newest";
}

// Get recently viewed media
$sql = "
    SELECT
        vh.id AS history_id,
        m.id,
        m.title,
        m.description,
        m.file_name,
        m.media_type,
        m.created_at AS uploaded_at,
        c.name AS category_name,
        vh.viewed_at
    FROM viewing_history vh
    INNER JOIN media m ON vh.media_id = m.id
    LEFT JOIN categories c ON m.category_id = c.id
    WHERE vh.user_id = ?
";

$params = [$userId];

// Search filter
if ($search !== "") {
    $sql .= " AND (m.title LIKE ? OR m.description LIKE ?)";
    $keyword = "%" . $search . "%";
    $params[] = $keyword;
    $params[] = $keyword;
}

// Media type filter
if ($type !== "all") {
    $sql .= " AND m.media_type = ?";
    $params[] = $type;
}

// Sorting
$sql .= $sort === "oldest"
    ? " ORDER BY vh.viewed_at ASC, vh.id ASC"
    : " ORDER BY vh.viewed_at DESC, vh.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$history = $stmt->fetchAll();

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Recently Viewed | ByteStream</title>

    <link rel="stylesheet" href="../assets/css/dashboard.css">

    <style>
        .history-container {
            padding: 30px;
            color: white;
        }

        .history-container h1 {
            color: #00eaff;
        }

        .history-container > a {
            color: #00eaff;
        }

        .history-filters {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 12px;
            margin-top: 25px;
        }

        .history-filters input,
        .history-filters select {
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #164e70;
            background: #101d35;
            color: white;
            min-width: 150px;
        }

        .history-filters input {
            flex: 1;
        }

        .filter-button {
            background: #00bce8;
            color: #071426;
            border: none;
            padding: 12px 18px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
        }

        .filter-button:hover {
            background: #00eaff;
        }

        .clear-filter {
            color: #00eaff;
            text-decoration: none;
            padding: 10px;
        }

        .history-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(270px, 1fr));
            gap: 22px;
            margin-top: 30px;
        }

        .history-card {
            background: #101d35;
            border: 1px solid #164e70;
            border-radius: 15px;
            padding: 18px;
            overflow: hidden;
            box-shadow: 0 0 15px rgba(0, 220, 255, 0.10);
        }

        .history-card h3 {
            color: #00eaff;
            margin: 15px 0 8px;
        }

        .history-card p {
            color: #c5d5e5;
            overflow-wrap: anywhere;
        }

        .history-card img,
        .history-card video {
            width: 100%;
            max-height: 230px;
            object-fit: contain;
            background: #050b16;
            border-radius: 10px;
        }

        .history-card img {
            cursor: pointer;
        }

        .history-card audio {
            width: 100%;
            margin-top: 12px;
        }

        .media-type {
            display: inline-block;
            padding: 5px 10px;
            background: #173b59;
            color: #00eaff;
            border-radius: 20px;
            font-size: 12px;
            margin-top: 8px;
        }

        .category-label {
            color: #b69cff !important;
            font-size: 13px;
        }

        .history-date {
            display: block;
            color: #91a8bd;
            font-size: 12px;
            margin-top: 12px;
        }

        .clear-button {
            background: #e63946;
            color: white;
            border: none;
            padding: 10px 16px;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 20px;
        }

        .clear-button:hover {
            background: #ff5260;
        }

        .success-message {
            color: #00eaff;
            margin-top: 15px;
        }

        .empty-history {
            margin-top: 30px;
            color: #c5d5e5;
        }

        @media (max-width: 600px) {
            .history-container {
                padding: 18px;
            }

            .history-filters {
                flex-direction: column;
                align-items: stretch;
            }

            .history-filters input,
            .history-filters select {
                width: 100%;
                box-sizing: border-box;
            }
        }
    </style>
</head>

<body>

<div class="history-container">

    <h1>Recently Viewed</h1>

    <p>Continue exploring the media you recently opened.</p>

    <a href="../dashboard.php">← Back to Dashboard</a>

    <?php if ($message): ?>
        <p class="success-message"><?= e($message) ?></p>
    <?php endif; ?>

    <!-- SEARCH AND FILTERS -->
    <form method="GET" class="history-filters">

        <input
            type="search"
            name="search"
            placeholder="Search recently viewed media..."
            value="<?= e($search) ?>"
        >

        <select name="type">
            <option value="all" <?= $type === "all" ? "selected" : "" ?>>
                All Media
            </option>

            <option value="video" <?= $type === "video" ? "selected" : "" ?>>
                Videos
            </option>

            <option value="photo" <?= $type === "photo" ? "selected" : "" ?>>
                Photos
            </option>

            <option value="audio" <?= $type === "audio" ? "selected" : "" ?>>
                Audio
            </option>
        </select>

        <select name="sort">
            <option value="newest" <?= $sort === "newest" ? "selected" : "" ?>>
                Newest First
            </option>

            <option value="oldest" <?= $sort === "oldest" ? "selected" : "" ?>>
                Oldest First
            </option>
        </select>

        <button type="submit" class="filter-button">
            Apply
        </button>

        <a href="recently-viewed.php" class="clear-filter">
            Clear Filters
        </a>

    </form>

    <?php if (!empty($history)): ?>

        <!-- CLEAR HISTORY -->
        <form
            method="POST"
            onsubmit="return confirm('Are you sure you want to clear your viewing history?');"
        >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= e($_SESSION["csrf_token"]) ?>"
            >

            <button type="submit" name="clear_history" class="clear-button">
                Clear Viewing History
            </button>

        </form>

        <div class="history-grid">

            <?php foreach ($history as $item): ?>

                <?php
                    $folders = [
                        "video" => "videos",
                        "photo" => "photos",
                        "audio" => "audio"
                    ];

                    $folder = $folders[$item["media_type"]] ?? null;

                    $fileUrl = $folder
                        ? "../uploads/" . $folder . "/" .
                          rawurlencode(basename($item["file_name"]))
                        : "";
                ?>

                <article class="history-card">

                    <?php if ($item["media_type"] === "video"): ?>

                        <video
                            controls
                            preload="metadata"
                            data-media-id="<?= (int)$item["id"] ?>"
                        >
                            <source src="<?= e($fileUrl) ?>">
                            Your browser does not support video playback.
                        </video>

                    <?php elseif ($item["media_type"] === "photo"): ?>

                        <a
                            href="<?= e($fileUrl) ?>"
                            target="_blank"
                            data-photo-id="<?= (int)$item["id"] ?>"
                        >
                            <img
                                src="<?= e($fileUrl) ?>"
                                alt="<?= e($item["title"]) ?>"
                                loading="lazy"
                            >
                        </a>

                    <?php elseif ($item["media_type"] === "audio"): ?>

                        <div style="font-size: 35px;">🎵</div>

                        <audio
                            controls
                            preload="metadata"
                            data-media-id="<?= (int)$item["id"] ?>"
                        >
                            <source src="<?= e($fileUrl) ?>">
                            Your browser does not support audio playback.
                        </audio>

                    <?php endif; ?>

                    <h3><?= e($item["title"]) ?></h3>

                    <p><?= nl2br(e($item["description"])) ?></p>

                    <span class="media-type">
                        <?= e(ucfirst($item["media_type"])) ?>
                    </span>

                    <p class="category-label">
                        Category:
                        <?= e($item["category_name"] ?? "Uncategorized") ?>
                    </p>

                    <span class="history-date">
                        Viewed:
                        <?= e(date("M d, Y h:i A", strtotime($item["viewed_at"]))) ?>
                    </span>

                </article>

            <?php endforeach; ?>

        </div>

    <?php else: ?>

        <p class="empty-history">
            You haven't viewed any media yet, or no results match your filters.
        </p>

    <?php endif; ?>

</div>

<script>
const csrfToken = <?= json_encode($_SESSION["csrf_token"]) ?>;

// Track video and audio views
document.querySelectorAll("[data-media-id]").forEach(media => {

    media.addEventListener("play", async function () {

        if (media.dataset.tracked === "true") return;

        media.dataset.tracked = "true";

        const formData = new FormData();
        formData.append("media_id", media.dataset.mediaId);

        try {
            const response = await fetch("track-view.php", {
                method: "POST",
                headers: {
                    "X-CSRF-Token": csrfToken
                },
                body: formData
            });

            if (!response.ok) {
                media.dataset.tracked = "false";
            }

        } catch (error) {
            media.dataset.tracked = "false";
        }

    });

});

// Track photo views
document.querySelectorAll("[data-photo-id]").forEach(photo => {

    photo.addEventListener("click", async function () {

        const formData = new FormData();
        formData.append("media_id", photo.dataset.photoId);

        try {
            await fetch("track-view.php", {
                method: "POST",
                headers: {
                    "X-CSRF-Token": csrfToken
                },
                body: formData
            });

        } catch (error) {
            console.error("Unable to track photo view.");
        }

    });

});
</script>

</body>
</html>
