
<?php

function logActivity(PDO $pdo, ?int $userId, string $action): void
{
    try {
        $stmt = $pdo->prepare("
            INSERT INTO activity_logs (user_id, action)
            VALUES (?, ?)
        ");

        $stmt->execute([$userId, $action]);

    } catch (PDOException $e) {
        // Keep the main website working even if logging fails.
        error_log("Activity logging failed: " . $e->getMessage());
    }
}
