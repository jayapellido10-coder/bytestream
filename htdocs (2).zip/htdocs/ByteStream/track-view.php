
<?php
session_start();

require_once __DIR__ . "/../config/database.php";

header("Content-Type: application/json; charset=UTF-8");

// Check user session
if (
    !isset($_SESSION["user_id"]) ||
    ($_SESSION["role"] ?? "") !== "user"
) {
    http_response_code(401);
    echo json_encode([
        "success" => false,
        "message" => "Unauthorized access."
    ]);
    exit;
}

// Allow POST requests only
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Method not allowed."
    ]);
    exit;
}

// Validate CSRF token
$token = $_SERVER["HTTP_X_CSRF_TOKEN"] ?? "";

if (
    empty($_SESSION["csrf_token"]) ||
    !hash_equals($_SESSION["csrf_token"], $token)
) {
    http_response_code(403);
    echo json_encode([
        "success" => false,
        "message" => "Invalid security token."
    ]);
    exit;
}

// Validate media ID
$mediaId = filter_input(INPUT_POST, "media_id", FILTER_VALIDATE_INT);

if (!$mediaId || $mediaId < 1) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Invalid media ID."
    ]);
    exit;
}

try {
    // Check if media exists
    $check = $pdo->prepare(
        "SELECT id FROM media WHERE id = ?"
    );
    $check->execute([$mediaId]);

    if (!$check->fetch()) {
        http_response_code(404);
        echo json_encode([
            "success" => false,
            "message" => "Media not found."
        ]);
        exit;
    }

    // Save viewing history
    $insert = $pdo->prepare("
        INSERT INTO viewing_history (user_id, media_id)
        VALUES (?, ?)
    ");

    $insert->execute([
        (int) $_SESSION["user_id"],
        $mediaId
    ]);

    echo json_encode([
        "success" => true,
        "message" => "Viewing history recorded."
    ]);

} catch (PDOException $e) {
    error_log("Track view error: " . $e->getMessage());

    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Unable to record viewing history."
    ]);
}
