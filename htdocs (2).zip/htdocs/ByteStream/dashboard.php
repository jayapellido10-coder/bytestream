
<?php
session_start();

// Login protection
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

// Regular user protection
if (($_SESSION["role"] ?? "") !== "user") {
    header("Location: admin/dashboard.php");
    exit;
}

require_once __DIR__ . "/config/database.php";

// Get current user's information
$stmt = $pdo->prepare("
    SELECT username, profile_picture
    FROM users
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([$_SESSION["user_id"]]);
$currentUser = $stmt->fetch();

$username = htmlspecialchars(
    $currentUser["username"] ?? $_SESSION["username"] ?? "User",
    ENT_QUOTES,
    "UTF-8"
);

// Get profile picture safely
if (!empty($currentUser["profile_picture"])) {
    $profilePicture = "uploads/profiles/" .
        rawurlencode(basename($currentUser["profile_picture"]));
} else {
    $profilePicture = "assets/images/default-avatar.png";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>ByteStream - Dashboard</title>

    <link rel="stylesheet" href="assets/css/dashboard.css">

    <style>
        .dashboard-search {
            display: flex;
            gap: 10px;
            width: 100%;
            max-width: 500px;
            margin-top: 25px;
        }

        .dashboard-search input {
            flex: 1;
            min-width: 0;
            padding: 13px 16px;
            border: 1px solid #28718f;
            border-radius: 9px;
            outline: none;
            background: #10243b;
            color: white;
            font-size: 14px;
        }

        .dashboard-search input:focus {
            border-color: #35d9ff;
            box-shadow: 0 0 12px #00c8ff33;
        }

        .dashboard-search button {
            padding: 13px 22px;
            border: none;
            border-radius: 9px;
            background: #35d9ff;
            color: #071426;
            font-weight: bold;
            cursor: pointer;
            transition: .2s;
        }

        .dashboard-search button:hover {
            background: #9b72ff;
            color: white;
        }

        .search-card {
            border: 1px solid #35d9ff !important;
            background: linear-gradient(135deg, #102f4d, #24234c) !important;
        }

        .search-card:hover {
            box-shadow: 0 0 22px #00c8ff44;
        }

        .media-card {
            text-decoration: none;
            cursor: pointer;
        }

        .media-card span {
            font-size: 28px;
            display: block;
            margin-bottom: 12px;
        }

        .sidebar nav a.active {
            color: #35d9ff;
        }

        /* Profile picture in sidebar */
        .sidebar-profile {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px;
            margin-bottom: 15px;
            border: 1px solid #28718f;
            border-radius: 12px;
            background: #10243b;
            text-decoration: none;
            color: white;
            transition: .2s;
        }

        .sidebar-profile:hover {
            border-color: #35d9ff;
            box-shadow: 0 0 15px #00c8ff33;
        }

        .sidebar-profile img {
            width: 43px;
            height: 43px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #35d9ff;
        }

        .sidebar-profile-info {
            min-width: 0;
        }

        .sidebar-profile-info strong {
            display: block;
            font-size: 14px;
            overflow-wrap: anywhere;
        }

        .sidebar-profile-info small {
            color: #35d9ff;
            font-size: 11px;
        }

        /* Profile picture in topbar */
        .topbar-profile {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            color: white;
            font-size: 14px;
        }

        .topbar-profile img {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #35d9ff;
            box-shadow: 0 0 12px #00c8ff44;
        }

        @media (max-width: 500px) {
            .dashboard-search {
                flex-direction: column;
            }

            .dashboard-search button {
                width: 100%;
            }

            .topbar-profile span {
                display: none;
            }
        }

        
    </style>

</head>

<body>

<div class="sidebar">

    <h2>ByteStream</h2>

    <a href="pages/account.php" class="sidebar-profile">
        <img
            src="<?= htmlspecialchars($profilePicture, ENT_QUOTES, 'UTF-8') ?>"
            alt="Profile Picture"
        >

        <div class="sidebar-profile-info">
            <strong><?= $username ?></strong>
            <small>View My Profile</small>
        </div>
    </a>

    <nav>
        <a href="pages/home.php" class="active">⌂ Home</a>
        <a href="search.php">🔎 Search Media</a>
        <a href="pages/videos.php">▶ Videos</a>
        <a href="pages/gallery.php">▧ Photo Gallery</a>
        <a href="pages/audio.php">♫ MP3 / Audio</a>
        <a href="pages/about.php">ⓘ About CCS</a>
        <a href="pages/favorites.php">♡ My Favorites</a>
        <a href="pages/recently-viewed.php">◷ Recently Viewed</a>
    </nav>

    <div class="sidebar-bottom">
        <a href="pages/account.php">👤 My Account</a>
        <a href="logout.php">↪ Logout</a>
    </div>

</div>

<main class="main-content">

    <header class="topbar">

        <h2>Home</h2>

        <a href="pages/account.php" class="topbar-profile">
            <img
                src="<?= htmlspecialchars($profilePicture, ENT_QUOTES, 'UTF-8') ?>"
                alt="Profile Picture"
            >
            <span>Welcome, <?= $username ?>!</span>
        </a>

    </header>

    <section class="welcome-section">

        <p class="eyebrow">YOUR DIGITAL MEDIA HUB</p>

        <h1>Welcome to ByteStream</h1>

        <p>
            Explore videos, discover photos, and enjoy your favorite audio
            content in one place. Your digital world starts here.
        </p>

        <form
            action="search.php"
            method="GET"
            class="dashboard-search"
        >

            <input
                type="search"
                name="q"
                placeholder="Search videos, photos, and audio..."
                aria-label="Search media"
                required
            >

            <button type="submit">Search</button>

        </form>

    </section>

    <section class="media-section">

        <h2>Explore ByteStream</h2>

        <div class="media-grid">

            <a href="search.php" class="media-card search-card">
                <span>🔎</span>
                <h3>Search Media</h3>
                <p>Find videos, photos, and audio using keywords.</p>
            </a>

            <a href="pages/videos.php" class="media-card">
                <span>▶</span>
                <h3>Videos</h3>
                <p>Watch your favorite videos.</p>
            </a>

            <a href="pages/gallery.php" class="media-card">
                <span>▧</span>
                <h3>Photo Gallery</h3>
                <p>Explore amazing photographs.</p>
            </a>

            <a href="pages/audio.php" class="media-card">
                <span>♫</span>
                <h3>MP3 / Audio</h3>
                <p>Listen to your favorite audio.</p>
            </a>

            <a href="pages/favorites.php" class="media-card">
                <span>♡</span>
                <h3>My Favorites</h3>
                <p>Find your saved media.</p>
            </a>

            <a href="pages/recently-viewed.php" class="media-card">
                <span>◷</span>
                <h3>Recently Viewed</h3>
                <p>Continue exploring your viewing history.</p>
            </a>

            <a href="pages/about.php" class="media-card">
                <span>ⓘ</span>
                <h3>About CCS</h3>
                <p>Learn more about CCS and the ByteStream platform.</p>
            </a>

            <a href="pages/account.php" class="media-card">
                <span>👤</span>
                <h3>My Account</h3>
                <p>View your profile and manage account settings.</p>
            </a>

        </div>

    </section>

</main>

</body>
</html>
