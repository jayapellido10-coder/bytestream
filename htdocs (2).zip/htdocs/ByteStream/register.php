
<?php
session_start();

require_once "config/database.php";
require_once "config/activity.php";

$errors = [];
$success = "";

$username = "";
$email = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST["username"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirmPassword = $_POST["confirm_password"] ?? "";

    // Validate username
    if (strlen($username) < 3) {
        $errors[] = "Username must be at least 3 characters.";
    }

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }

    // Validate password
    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters.";
    }

    // Confirm password
    if ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match.";
    }

    // Check duplicate username and email
    if (empty($errors)) {

        $check = $pdo->prepare("
            SELECT id
            FROM users
            WHERE username = ? OR email = ?
        ");

        $check->execute([$username, $email]);

        if ($check->fetch()) {
            $errors[] = "Username or email is already registered.";
        }
    }

    // Create account
    if (empty($errors)) {

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        try {
            $stmt = $pdo->prepare("
                INSERT INTO users (username, email, password, role)
                VALUES (?, ?, ?, 'user')
            ");

            $stmt->execute([
                $username,
                $email,
                $hashedPassword
            ]);

            // Get newly created user ID
            $newUserId = (int) $pdo->lastInsertId();

            // Record registration in Activity Logs
            logActivity(
                $pdo,
                $newUserId,
                "Created a new user account"
            );

            $success = "Account created successfully! You can now log in.";

            // Clear form values
            $username = "";
            $email = "";

        } catch (PDOException $e) {
            error_log("Registration failed: " . $e->getMessage());
            $errors[] = "Registration failed. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Create Account | ByteStream</title>

    <link rel="stylesheet" href="assets/css/register.css">
</head>

<body>

    <div class="register-container">

        <div class="register-box">

            <h1>ByteStream</h1>
            <h2>Create Account</h2>

            <p>Join ByteStream and explore digital media.</p>

            <?php if (!empty($errors)): ?>

                <div class="error-message">
                    <?php foreach ($errors as $error): ?>
                        <p><?= htmlspecialchars($error) ?></p>
                    <?php endforeach; ?>
                </div>

            <?php endif; ?>

            <?php if ($success): ?>

                <div class="success-message">
                    <?= htmlspecialchars($success) ?>
                </div>

            <?php endif; ?>

            <form method="POST" action="register.php">

                <div class="form-group">
                    <label for="username">Username</label>

                    <input
                        type="text"
                        id="username"
                        name="username"
                        placeholder="Enter your username"
                        value="<?= htmlspecialchars($username) ?>"
                        minlength="3"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="email">Email Address</label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="Enter your email"
                        value="<?= htmlspecialchars($email) ?>"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="password">Password</label>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Create a password"
                        minlength="8"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>

                    <input
                        type="password"
                        id="confirm_password"
                        name="confirm_password"
                        placeholder="Confirm your password"
                        minlength="8"
                        required
                    >
                </div>

                <button type="submit">
                    Create Account
                </button>

            </form>

            <p class="login-link">
                Already have an account?
                <a href="login.php">Sign In</a>
            </p>

        </div>

    </div>

</body>
</html>
