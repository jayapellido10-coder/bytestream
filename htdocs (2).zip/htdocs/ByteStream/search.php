
<?php
session_start();

require_once __DIR__ . "/config/database.php";

// Check user access
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

if ($_SESSION["role"] === "admin") {
    header("Location: admin/dashboard.php");
    exit;
}

$userId = (int) $_SESSION["user_id"];

if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION["csrf_token"];

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

// Search and filter values
$search = trim($_GET["q"] ?? "");

$allowedTypes = ["all", "video", "photo", "audio"];
$type = $_GET["type"] ?? "all";

if (!in_array($type, $allowedTypes, true)) {
    $type = "all";
}

$allowedSorts = ["newest", "oldest"];
$sort = $_GET["sort"] ?? "newest";

if (!in_array($sort, $allowedSorts, true)) {
    $sort = "newest";
}

// Add to Favorites
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $postedToken = $_POST["csrf_token"] ?? "";

    if (!hash_equals($csrfToken, $postedToken)) {
        exit("Invalid request. Please refresh the page.");
    }

    if (isset($_POST["add_favorite"])) {

        $mediaId = filter_var(
            $_POST["media_id"] ?? null,
            FILTER_VALIDATE_INT
        );

        if ($mediaId) {
            $check = $pdo->prepare(
                "SELECT id FROM media WHERE id = ?"
            );
            $check->execute([$mediaId]);

            if ($check->fetch()) {
                $favorite = $pdo->prepare(
                    "INSERT IGNORE INTO favorites (user_id, media_id)
                     VALUES (?, ?)"
                );
                $favorite->execute([$userId, $mediaId]);
            }
        }
    }

    header("Location: search.php?" . http_build_query([
        "q" => $search,
        "type" => $type,
        "sort" => $sort
    ]));
    exit;
}

// Build search query
$sql = "
    SELECT
        m.*,
        EXISTS (
            SELECT 1
            FROM favorites f
            WHERE f.media_id = m.id
            AND f.user_id = ?
        ) AS is_favorite
    FROM media m
    WHERE 1 = 1
";

$params = [$userId];

if ($search !== "") {
    $sql .= " AND (m.title LIKE ? OR m.description LIKE ?)";
    $keyword = "%" . $search . "%";
    $params[] = $keyword;
    $params[] = $keyword;
}

if ($type !== "all") {
    $sql .= " AND m.media_type = ?";
    $params[] = $type;
}

if ($sort === "oldest") {
    $sql .= " ORDER BY m.created_at ASC, m.id ASC";
} else {
    $sql .= " ORDER BY m.created_at DESC, m.id DESC";
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$results = $stmt->fetchAll();

$uploadFolders = [
    "video" => "uploads/videos/",
    "photo" => "uploads/photos/",
    "audio" => "uploads/audio/"
];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Search Media | ByteStream</title>

    <link rel="stylesheet" href="assets/css/dashboard.css">

    <style>
        body {
            background: #071426;
            color: #eaf6ff;
            font-family: Arial, sans-serif;
        }

        .search-container {
            max-width: 1200px;
            margin: 35px auto;
            padding: 20px;
        }

        .search-heading h1 {
            color: #35d9ff;
            font-size: 30px;
        }

        .search-heading p {
            color: #a9c5dc;
        }

        .search-panel {
            background: rgba(15, 35, 60, 0.95);
            border: 1px solid rgba(53, 217, 255, 0.3);
            border-radius: 15px;
            padding: 22px;
            margin: 25px 0;
        }

        .search-form {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr auto;
            gap: 12px;
        }

        .search-form input,
        .search-form select {
            width: 100%;
            box-sizing: border-box;
            padding: 13px;
            border-radius: 8px;
            border: 1px solid #285273;
            background: #091c30;
            color: white;
            outline: none;
        }

        .search-form input:focus,
        .search-form select:focus {
            border-color: #35d9ff;
        }

        .search-btn {
            padding: 13px 22px;
            border: none;
            border-radius: 8px;
            background: linear-gradient(90deg, #00bce8, #5865f2);
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        .results-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
            margin: 30px 0 20px;
        }

        .results-heading h2 {
            color: #35d9ff;
        }

        .media-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 22px;
        }

        .media-card {
            background: rgba(15, 35, 60, 0.95);
            border: 1px solid rgba(53, 217, 255, 0.25);
            border-radius: 13px;
            padding: 15px;
            overflow: hidden;
        }

        .media-card video,
        .media-card audio,
        .media-card img {
            width: 100%;
            border-radius: 9px;
        }

        .media-card video {
            max-height: 220px;
            background: #000;
        }

        .media-card img {
            height: 200px;
            object-fit: cover;
            cursor: pointer;
        }

        .media-card h3 {
            color: #35d9ff;
            margin: 14px 0 8px;
            overflow-wrap: anywhere;
        }

        .media-description {
            color: #b5c9dc;
            font-size: 14px;
            overflow-wrap: anywhere;
        }

        .media-type {
            color: #9eb8d0;
            font-size: 12px;
            text-transform: uppercase;
        }

        .favorite-btn {
            width: 100%;
            margin-top: 15px;
            padding: 11px;
            border: 1px solid #35d9ff;
            border-radius: 8px;
            background: transparent;
            color: #35d9ff;
            font-weight: bold;
            cursor: pointer;
        }

        .favorite-btn:hover {
            background: #35d9ff;
            color: #071426;
        }

        .favorite-btn.added {
            border-color: #00d99a;
            color: #00d99a;
            cursor: default;
        }

        .empty-results {
            text-align: center;
            padding: 50px 20px;
            background: rgba(15, 35, 60, 0.8);
            border-radius: 12px;
            color: #a9c5dc;
        }

        .back-link {
            display: inline-block;
            color: #35d9ff;
            text-decoration: none;
            margin-bottom: 20px;
        }

        @media (max-width: 750px) {
            .search-form {
                grid-template-columns: 1fr;
            }

            .search-container {
                padding: 15px;
            }
        }
    </style>
</head>

<body>

<div class="search-container">

    <a href="dashboard.php" class="back-link">
        ← Back to Dashboard
    </a>

    <div class="search-heading">
        <h1>Search Media</h1>
        <p>Discover videos, photos, and audio in ByteStream.</p>
    </div>

    <div class="search-panel">

        <form method="GET" action="search.php" class="search-form">

            <input
                type="search"
                name="q"
                placeholder="Search media title or description..."
                value="<?= e($search) ?>"
            >

            <select name="type">
                <option value="all" <?= $type === "all" ? "selected" : "" ?>>
                    All Media
                </option>

                <option value="video" <?= $type === "video" ? "selected" : "" ?>>
                    Videos
                </option>

                <option value="photo" <?= $type === "photo" ? "selected" : "" ?>>
                    Photos
                </option>

                <option value="audio" <?= $type === "audio" ? "selected" : "" ?>>
                    Audio
                </option>
            </select>

            <select name="sort">
                <option value="newest" <?= $sort === "newest" ? "selected" : "" ?>>
                    Newest First
                </option>

                <option value="oldest" <?= $sort === "oldest" ? "selected" : "" ?>>
                    Oldest First
                </option>
            </select>

            <button type="submit" class="search-btn">
                Search
            </button>

        </form>

    </div>

    <div class="results-heading">
        <h2>Search Results</h2>
        <span><?= count($results) ?> media found</span>
    </div>

    <?php if (count($results) > 0): ?>

        <div class="media-grid">

            <?php foreach ($results as $media): ?>

                <?php
                    $mediaType = $media["media_type"];
                    $filePath = $uploadFolders[$mediaType] . $media["file_name"];
                    $isFavorite = (bool)$media["is_favorite"];
                ?>

                <div class="media-card">

                    <span class="media-type">
                        <?= e($mediaType) ?>
                    </span>

                    <?php if ($mediaType === "video"): ?>

                        <video controls preload="metadata">
                            <source src="<?= e($filePath) ?>">
                            Your browser does not support video playback.
                        </video>

                    <?php elseif ($mediaType === "photo"): ?>

                        <img
                            src="<?= e($filePath) ?>"
                            alt="<?= e($media["title"]) ?>"
                            loading="lazy"
                        >

                    <?php elseif ($mediaType === "audio"): ?>

                        <audio controls preload="metadata">
                            <source src="<?= e($filePath) ?>">
                            Your browser does not support audio playback.
                        </audio>

                    <?php endif; ?>

                    <h3><?= e($media["title"]) ?></h3>

                    <p class="media-description">
                        <?= e($media["description"] ?? "No description available.") ?>
                    </p>

                    <small>
                        Uploaded:
                        <?= e(date("M d, Y", strtotime($media["created_at"]))) ?>
                    </small>

                    <form method="POST">

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= e($csrfToken) ?>"
                        >

                        <input
                            type="hidden"
                            name="media_id"
                            value="<?= (int)$media["id"] ?>"
                        >

                        <input
                            type="hidden"
                            name="q"
                            value="<?= e($search) ?>"
                        >

                        <input
                            type="hidden"
                            name="type"
                            value="<?= e($type) ?>"
                        >

                        <input
                            type="hidden"
                            name="sort"
                            value="<?= e($sort) ?>"
                        >

                        <?php if ($isFavorite): ?>

                            <button
                                type="button"
                                class="favorite-btn added"
                                disabled
                            >
                                ✓ Added to Favorites
                            </button>

                        <?php else: ?>

                            <button
                                type="submit"
                                name="add_favorite"
                                value="1"
                                class="favorite-btn"
                            >
                                + Add to Favorites
                            </button>

                        <?php endif; ?>

                    </form>

                </div>

            <?php endforeach; ?>

        </div>

    <?php else: ?>

        <div class="empty-results">
            <h2>No Media Found</h2>
            <p>Try another keyword or change your filters.</p>
        </div>

    <?php endif; ?>

</div>

<script>
const csrfToken = <?= json_encode($csrfToken) ?>;
const trackedMedia = new Set();

function trackMedia(mediaId) {
    if (trackedMedia.has(mediaId)) {
        return;
    }

    trackedMedia.add(mediaId);

    fetch("pages/track-view.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-CSRF-Token": csrfToken
        },
        body: JSON.stringify({
            media_id: mediaId
        })
    }).catch(() => {
        trackedMedia.delete(mediaId);
    });
}

// Track video and audio playback
document.querySelectorAll("video, audio").forEach(player => {
    player.addEventListener("play", () => {
        const card = player.closest(".media-card");
        const mediaId = card?.querySelector('input[name="media_id"]')?.value;

        if (mediaId) {
            trackMedia(mediaId);
        }
    });
});

// Track photo viewing
document.querySelectorAll(".media-card img").forEach(photo => {
    photo.addEventListener("click", () => {
        const card = photo.closest(".media-card");
        const mediaId = card?.querySelector('input[name="media_id"]')?.value;

        if (mediaId) {
            trackMedia(mediaId);
        }
    });
});
</script>

</body>
</html>
