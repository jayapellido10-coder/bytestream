
<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

if (($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: ../dashboard.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/activity.php';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message = '';
$error = '';

// Get admin information
$stmt = $pdo->prepare("
    SELECT id, username, email, profile_picture, created_at, password
    FROM users
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([$_SESSION['user_id']]);
$admin = $stmt->fetch();

if (!$admin) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

// Upload profile picture
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_picture'])) {

    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please refresh the page.';
    } elseif (
        !isset($_FILES['profile_picture']) ||
        $_FILES['profile_picture']['error'] !== UPLOAD_ERR_OK
    ) {
        $error = 'Please select a valid image.';
    } else {
        $file = $_FILES['profile_picture'];
        $maxSize = 5 * 1024 * 1024;

        if ($file['size'] > $maxSize) {
            $error = 'Image must not exceed 5MB.';
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($file['tmp_name']);

            $allowed = [
                'image/jpeg' => 'jpg',
                'image/png' => 'png',
                'image/webp' => 'webp'
            ];

            if (!isset($allowed[$mime])) {
                $error = 'Only JPG, PNG, and WEBP images are allowed.';
            } else {
                $uploadDir = __DIR__ . '/../uploads/profiles/';

                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }

                $fileName = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
                $destination = $uploadDir . $fileName;

                if (move_uploaded_file($file['tmp_name'], $destination)) {
                    $oldPicture = $admin['profile_picture'];

                    try {
                        $stmt = $pdo->prepare("
                            UPDATE users
                            SET profile_picture = ?
                            WHERE id = ?
                        ");
                        $stmt->execute([$fileName, $_SESSION['user_id']]);

                        logActivity(
                            $pdo,
                            (int) $_SESSION['user_id'],
                            'Admin updated profile picture'
                        );

                        // Delete previous uploaded picture
                        if (!empty($oldPicture)) {
                            $oldPath = $uploadDir . basename($oldPicture);

                            if (is_file($oldPath)) {
                                unlink($oldPath);
                            }
                        }

                        header('Location: account.php?updated=1');
                        exit;

                    } catch (PDOException $e) {
                        if (is_file($destination)) {
                            unlink($destination);
                        }

                        error_log($e->getMessage());
                        $error = 'Unable to save profile picture.';
                    }
                } else {
                    $error = 'Unable to upload image. Check folder permissions.';
                }
            }
        }
    }
}

// Change password
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {

    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please refresh the page.';
    } else {
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if (!password_verify($currentPassword, $admin['password'])) {
            $error = 'Current password is incorrect.';
        } elseif (strlen($newPassword) < 8) {
            $error = 'New password must be at least 8 characters.';
        } elseif ($newPassword !== $confirmPassword) {
            $error = 'New passwords do not match.';
        } else {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

            $stmt = $pdo->prepare("
                UPDATE users
                SET password = ?
                WHERE id = ?
            ");
            $stmt->execute([$hashedPassword, $_SESSION['user_id']]);

            logActivity(
                $pdo,
                (int) $_SESSION['user_id'],
                'Admin changed account password'
            );

            header('Location: account.php?password_changed=1');
            exit;
        }
    }
}

// Refresh admin information
$stmt = $pdo->prepare("
    SELECT id, username, email, profile_picture, created_at, password
    FROM users
    WHERE id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$admin = $stmt->fetch();

$picture = !empty($admin['profile_picture'])
    ? '../uploads/profiles/' . rawurlencode(basename($admin['profile_picture']))
    : '../assets/images/default-avatar.png';

if (isset($_GET['updated'])) {
    $message = 'Profile picture updated successfully!';
}

if (isset($_GET['password_changed'])) {
    $message = 'Password changed successfully!';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ByteStream - Admin Account</title>
    <link rel="stylesheet" href="../assets/css/admin.css">

    <style>
        .account-container {
            max-width: 850px;
            margin: 30px auto;
        }

        .account-card {
            background: #101d31;
            border: 1px solid rgba(0,234,255,.25);
            border-radius: 16px;
            padding: 28px;
            margin-bottom: 25px;
            color: white;
        }

        .account-card h2 {
            color: #00eaff;
            margin-top: 0;
        }

        .admin-avatar {
            width: 130px;
            height: 130px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #00eaff;
            box-shadow: 0 0 20px #00eaff55;
            display: block;
            margin: 15px auto;
        }

        .profile-center {
            text-align: center;
        }

        .account-card label {
            display: block;
            margin: 15px 0 7px;
            color: #b9d9e8;
        }

        .account-card input {
            width: 100%;
            box-sizing: border-box;
            padding: 12px;
            border: 1px solid #28718f;
            border-radius: 8px;
            background: #0b1728;
            color: white;
            outline: none;
        }

        .account-card input:focus {
            border-color: #00eaff;
        }

        .account-button {
            margin-top: 18px;
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            background: #00eaff;
            color: #071426;
            font-weight: bold;
            cursor: pointer;
        }

        .account-button:hover {
            background: #a78bfa;
            color: white;
        }

        .account-info p {
            padding: 12px 0;
            border-bottom: 1px solid #26384e;
            overflow-wrap: anywhere;
        }

        .success-message {
            background: #123d35;
            color: #8fffdc;
            padding: 13px;
            border-radius: 8px;
            margin-bottom: 18px;
        }

        .error-message {
            background: #481f2a;
            color: #ffb8c5;
            padding: 13px;
            border-radius: 8px;
            margin-bottom: 18px;
        }

        .back-link {
            color: #00eaff;
            text-decoration: none;
        }
    </style>
</head>

<body>

<aside class="admin-sidebar">
    <h2>ByteStream</h2>
    <p class="admin-label">ADMIN PANEL</p>

    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="users.php">Manage Users</a>
        <a href="upload.php">Upload Media</a>
        <a href="videos.php">Manage Videos</a>
        <a href="photos.php">Manage Photos</a>
        <a href="audio.php">Manage Audio</a>
        <a href="activity-logs.php">Activity Logs</a>
        <a href="account.php" class="active">My Account</a>
    </nav>

    <div class="sidebar-bottom">
        <a href="../dashboard.php">User Website</a>
        <a href="../logout.php">Logout</a>
    </div>
</aside>

<main class="admin-main">

    <header class="admin-topbar">
        <div>
            <p class="eyebrow">BYTESTREAM MANAGEMENT</p>
            <h1>My Admin Account</h1>
        </div>
    </header>

    <div class="account-container">

        <?php if ($message): ?>
            <div class="success-message">
                <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="error-message">
                <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <section class="account-card profile-center">

            <h2>Profile Picture</h2>

            <img
                src="<?= htmlspecialchars($picture, ENT_QUOTES, 'UTF-8') ?>"
                alt="Admin Profile"
                class="admin-avatar"
            >

            <form method="POST" enctype="multipart/form-data">

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>"
                >

                <label for="profile_picture">Choose New Profile Picture</label>

                <input
                    type="file"
                    name="profile_picture"
                    id="profile_picture"
                    accept=".jpg,.jpeg,.png,.webp"
                    required
                >

                <p><small>JPG, PNG, or WEBP. Maximum size: 5MB.</small></p>

                <button
                    type="submit"
                    name="upload_picture"
                    class="account-button"
                >
                    Upload Profile Picture
                </button>

            </form>

        </section>

        <section class="account-card account-info">

            <h2>Account Information</h2>

            <p>
                <strong>Username:</strong>
                <?= htmlspecialchars($admin['username'], ENT_QUOTES, 'UTF-8') ?>
            </p>

            <p>
                <strong>Email:</strong>
                <?= htmlspecialchars($admin['email'], ENT_QUOTES, 'UTF-8') ?>
            </p>

            <p><strong>Role:</strong> Administrator</p>

            <p>
                <strong>Account Created:</strong>
                <?= htmlspecialchars($admin['created_at'], ENT_QUOTES, 'UTF-8') ?>
            </p>

        </section>

        <section class="account-card">

            <h2>Change Password</h2>

            <form method="POST">

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>"
                >

                <label for="current_password">Current Password</label>
                <input
                    type="password"
                    name="current_password"
                    id="current_password"
                    required
                >

                <label for="new_password">New Password</label>
                <input
                    type="password"
                    name="new_password"
                    id="new_password"
                    minlength="8"
                    required
                >

                <label for="confirm_password">Confirm New Password</label>
                <input
                    type="password"
                    name="confirm_password"
                    id="confirm_password"
                    minlength="8"
                    required
                >

                <button
                    type="submit"
                    name="change_password"
                    class="account-button"
                >
                    Update Password
                </button>

            </form>

        </section>

        <a href="dashboard.php" class="back-link">← Back to Admin Dashboard</a>

    </div>

</main>

</body>
</html>
