
<?php
session_start();

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../config/activity.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: ../login.php");
    exit;
}

$adminId = (int) $_SESSION["user_id"];

if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$message = "";
$messageType = "";

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

// Add or delete category
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $token = $_POST["csrf_token"] ?? "";

    if (!hash_equals($_SESSION["csrf_token"], $token)) {
        $message = "Invalid request. Please refresh the page.";
        $messageType = "error";

    } elseif (isset($_POST["add_category"])) {

        $name = trim($_POST["name"] ?? "");
        $mediaType = $_POST["media_type"] ?? "";

        if ($name === "" || strlen($name) > 100) {
            $message = "Enter a category name with a maximum of 100 characters.";
            $messageType = "error";

        } elseif (!in_array($mediaType, ["video", "photo", "audio"], true)) {
            $message = "Please select a valid media type.";
            $messageType = "error";

        } else {
            $check = $pdo->prepare(
                "SELECT id FROM categories WHERE name = ? AND media_type = ?"
            );
            $check->execute([$name, $mediaType]);

            if ($check->fetch()) {
                $message = "This category already exists for that media type.";
                $messageType = "error";

            } else {
                $insert = $pdo->prepare(
                    "INSERT INTO categories (name, media_type) VALUES (?, ?)"
                );
                $insert->execute([$name, $mediaType]);

                logActivity(
                    $pdo,
                    $adminId,
                    "Created category: " . $name
                );

                $message = "Category created successfully!";
                $messageType = "success";
            }
        }

    } elseif (isset($_POST["delete_category"])) {

        $categoryId = filter_var(
            $_POST["category_id"] ?? null,
            FILTER_VALIDATE_INT
        );

        if (!$categoryId) {
            $message = "Invalid category.";
            $messageType = "error";

        } else {
            $find = $pdo->prepare(
                "SELECT name FROM categories WHERE id = ?"
            );
            $find->execute([$categoryId]);
            $category = $find->fetch();

            if ($category) {
                $delete = $pdo->prepare(
                    "DELETE FROM categories WHERE id = ?"
                );
                $delete->execute([$categoryId]);

                logActivity(
                    $pdo,
                    $adminId,
                    "Deleted category: " . $category["name"]
                );

                $message = "Category deleted successfully!";
                $messageType = "success";

            } else {
                $message = "Category not found.";
                $messageType = "error";
            }
        }
    }
}

// Get categories
$stmt = $pdo->query("
    SELECT
        c.id,
        c.name,
        c.media_type,
        COUNT(m.id) AS media_count
    FROM categories c
    LEFT JOIN media m ON m.category_id = c.id
    GROUP BY c.id, c.name, c.media_type
    ORDER BY c.media_type ASC, c.name ASC
");

$categories = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category Management | ByteStream</title>
    <link rel="stylesheet" href="../assets/css/admin.css">

    <style>
        body {
            background: #071426;
            color: #eaf6ff;
            font-family: Arial, sans-serif;
        }

        .category-container {
            max-width: 1100px;
            margin: 35px auto;
            padding: 20px;
        }

        .category-header h1 {
            color: #35d9ff;
        }

        .category-card {
            background: rgba(15, 35, 60, .95);
            border: 1px solid rgba(53, 217, 255, .3);
            border-radius: 14px;
            padding: 22px;
            margin: 22px 0;
        }

        .category-card h2 {
            color: #35d9ff;
            margin-top: 0;
        }

        .category-form {
            display: grid;
            grid-template-columns: 2fr 1fr auto;
            gap: 12px;
        }

        .category-form input,
        .category-form select {
            padding: 13px;
            border-radius: 8px;
            border: 1px solid #285273;
            background: #091c30;
            color: white;
            min-width: 0;
        }

        .add-btn {
            background: linear-gradient(90deg, #00bce8, #5865f2);
            border: none;
            border-radius: 8px;
            color: white;
            padding: 12px 20px;
            font-weight: bold;
            cursor: pointer;
        }

        .category-table-wrapper {
            overflow-x: auto;
        }

        .category-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 550px;
        }

        .category-table th,
        .category-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid rgba(255,255,255,.1);
        }

        .category-table th {
            color: #35d9ff;
        }

        .type-label {
            color: #35d9ff;
            text-transform: uppercase;
            font-size: 12px;
        }

        .delete-btn {
            background: #d93650;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 9px 13px;
            cursor: pointer;
        }

        .message {
            padding: 13px;
            border-radius: 8px;
            margin: 15px 0;
        }

        .success {
            background: rgba(0, 200, 120, .15);
            color: #78ffc0;
        }

        .error {
            background: rgba(255, 60, 80, .15);
            color: #ff9eaa;
        }

        .back-link {
            color: #35d9ff;
            text-decoration: none;
        }

        @media(max-width: 700px) {
            .category-form {
                grid-template-columns: 1fr;
            }

            .category-container {
                padding: 15px;
            }
        }
    </style>
</head>

<body>

<div class="category-container">

    <a href="dashboard.php" class="back-link">
        ← Back to Admin Dashboard
    </a>

    <div class="category-header">
        <h1>Category Management</h1>
        <p>Create and manage media categories in ByteStream.</p>
    </div>

    <?php if ($message !== ""): ?>
        <div class="message <?= e($messageType) ?>">
            <?= e($message) ?>
        </div>
    <?php endif; ?>

    <div class="category-card">
        <h2>Add New Category</h2>

        <form method="POST" class="category-form">

            <input
                type="hidden"
                name="csrf_token"
                value="<?= e($_SESSION["csrf_token"]) ?>"
            >

            <input
                type="text"
                name="name"
                placeholder="Enter category name"
                maxlength="100"
                required
            >

            <select name="media_type" required>
                <option value="">Select Media Type</option>
                <option value="video">Video</option>
                <option value="photo">Photo</option>
                <option value="audio">Audio</option>
            </select>

            <button type="submit" name="add_category" class="add-btn">
                + Add Category
            </button>

        </form>
    </div>

    <div class="category-card">
        <h2>Existing Categories</h2>

        <div class="category-table-wrapper">
            <table class="category-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Category Name</th>
                        <th>Media Type</th>
                        <th>Media Count</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (count($categories) > 0): ?>

                        <?php foreach ($categories as $category): ?>
                            <tr>
                                <td><?= (int)$category["id"] ?></td>

                                <td><?= e($category["name"]) ?></td>

                                <td>
                                    <span class="type-label">
                                        <?= e($category["media_type"]) ?>
                                    </span>
                                </td>

                                <td><?= (int)$category["media_count"] ?></td>

                                <td>
                                    <form method="POST"
                                        onsubmit="return confirm('Delete this category? Existing media will remain but become uncategorized.');">

                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?= e($_SESSION["csrf_token"]) ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="category_id"
                                            value="<?= (int)$category["id"] ?>"
                                        >

                                        <button
                                            type="submit"
                                            name="delete_category"
                                            class="delete-btn"
                                        >
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                    <?php else: ?>
                        <tr>
                            <td colspan="5">
                                No categories created yet.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

</body>
</html>
