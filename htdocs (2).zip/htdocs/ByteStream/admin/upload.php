
<?php
session_start();

require_once "../config/database.php";
require_once "../config/activity.php";

// Admin access only
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

if ($_SESSION["role"] !== "admin") {
    header("Location: ../dashboard.php");
    exit;
}

// CSRF token
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$message = "";
$errors = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $token = $_POST["csrf_token"] ?? "";

    if (
        empty($_SESSION["csrf_token"]) ||
        !hash_equals($_SESSION["csrf_token"], $token)
    ) {
        http_response_code(403);
        exit("Invalid request.");
    }

    $title = trim($_POST["title"] ?? "");
    $description = trim($_POST["description"] ?? "");
    $mediaType = $_POST["media_type"] ?? "";

    $allowedTypes = ["video", "photo", "audio"];

    $fileRules = [
        "video" => [
            "extensions" => ["mp4", "webm"],
            "mime" => ["video/mp4", "video/webm"],
            "max_size" => 100 * 1024 * 1024,
            "folder" => "videos"
        ],
        "photo" => [
            "extensions" => ["jpg", "jpeg", "png", "gif", "webp"],
            "mime" => [
                "image/jpeg",
                "image/png",
                "image/gif",
                "image/webp"
            ],
            "max_size" => 10 * 1024 * 1024,
            "folder" => "photos"
        ],
        "audio" => [
            "extensions" => ["mp3", "wav", "ogg", "m4a"],
            "mime" => [
                "audio/mpeg",
                "audio/mp3",
                "audio/wav",
                "audio/x-wav",
                "audio/ogg",
                "audio/mp4",
                "audio/x-m4a"
            ],
            "max_size" => 20 * 1024 * 1024,
            "folder" => "audio"
        ]
    ];

    if ($title === "") {
        $errors[] = "Please enter a media title.";
    }

    if (!in_array($mediaType, $allowedTypes, true)) {
        $errors[] = "Please select a valid media type.";
    }

    if (!isset($_FILES["media_file"])) {
        $errors[] = "Please select a file.";
    } elseif ($_FILES["media_file"]["error"] !== UPLOAD_ERR_OK) {
        $errors[] = "File upload failed. Please try again.";
    }

    if (empty($errors)) {

        $file = $_FILES["media_file"];
        $originalName = $file["name"];
        $fileSize = (int) $file["size"];
        $extension = strtolower(
            pathinfo($originalName, PATHINFO_EXTENSION)
        );

        $rule = $fileRules[$mediaType];

        if (!in_array($extension, $rule["extensions"], true)) {
            $errors[] = "File extension is not allowed.";
        }

        if ($fileSize <= 0 || $fileSize > $rule["max_size"]) {
            $errors[] = "File size exceeds the allowed limit.";
        }

        if (!is_uploaded_file($file["tmp_name"])) {
            $errors[] = "Invalid uploaded file.";
        }

        if (empty($errors)) {

            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mimeType = $finfo->file($file["tmp_name"]);

            if (!in_array($mimeType, $rule["mime"], true)) {
                $errors[] = "File content does not match the selected type.";
            }
        }

        if (empty($errors)) {

            $newFileName = bin2hex(random_bytes(16)) . "." . $extension;

            $uploadDirectory = __DIR__ . "/../uploads/" . $rule["folder"];
            $destination = $uploadDirectory . "/" . $newFileName;

            if (!is_dir($uploadDirectory)) {
                $errors[] = "Upload directory does not exist.";
            } elseif (!is_writable($uploadDirectory)) {
                $errors[] = "Upload directory is not writable.";
            } elseif (!move_uploaded_file($file["tmp_name"], $destination)) {
                $errors[] = "Unable to save the uploaded file.";
            } else {

                try {

                    $stmt = $pdo->prepare("
                        INSERT INTO media
                        (title, description, file_name, media_type, uploaded_by)
                        VALUES (?, ?, ?, ?, ?)
                    ");

                    $stmt->execute([
                        $title,
                        $description,
                        $newFileName,
                        $mediaType,
                        $_SESSION["user_id"]
                    ]);

                    // Record upload activity
                    logActivity(
                        $pdo,
                        (int) $_SESSION["user_id"],
                        "Uploaded a " . $mediaType . ": " . $title
                    );

                    $message = "Media uploaded successfully!";

                } catch (PDOException $e) {

                    error_log("Media upload database error: " . $e->getMessage());

                    if (is_file($destination)) {
                        unlink($destination);
                    }

                    $errors[] = "Unable to save media information.";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Upload Center | ByteStream</title>

    <link rel="stylesheet" href="../assets/css/admin.css">

    <style>
        .upload-container {
            max-width: 750px;
            margin: 35px auto;
            padding: 25px;
        }

        .upload-container h1 {
            color: #00eaff;
        }

        .upload-form {
            background: #101d31;
            border: 1px solid rgba(0, 234, 255, .3);
            border-radius: 12px;
            padding: 25px;
            margin-top: 20px;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #00eaff;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            box-sizing: border-box;
            padding: 12px;
            background: #07111f;
            color: white;
            border: 1px solid #28435d;
            border-radius: 7px;
        }

        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }

        .upload-button {
            padding: 12px 22px;
            background: #00dff5;
            color: #07111f;
            border: none;
            border-radius: 7px;
            font-weight: bold;
            cursor: pointer;
        }

        .upload-button:hover {
            background: #8a2be2;
            color: white;
        }

        .success-message {
            color: #66ff99;
            margin-top: 15px;
        }

        .error-message {
            color: #ff7777;
            margin-top: 15px;
        }

        .back-link {
            display: inline-block;
            color: #00eaff;
            text-decoration: none;
            margin-top: 15px;
        }
    </style>
</head>

<body>

<div class="upload-container">

    <h1>Upload Center</h1>
    <p>Upload videos, photos, and audio files to ByteStream.</p>

    <a href="dashboard.php" class="back-link">
        ← Back to Admin Dashboard
    </a>

    <?php if ($message): ?>
        <p class="success-message">
            <?= htmlspecialchars($message) ?>
        </p>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
        <div class="error-message">
            <?php foreach ($errors as $error): ?>
                <p><?= htmlspecialchars($error) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form
        class="upload-form"
        method="POST"
        enctype="multipart/form-data"
    >

        <input
            type="hidden"
            name="csrf_token"
            value="<?= htmlspecialchars($_SESSION["csrf_token"]) ?>"
        >

        <div class="form-group">
            <label for="title">Media Title</label>
            <input
                type="text"
                id="title"
                name="title"
                placeholder="Enter media title"
                required
            >
        </div>

        <div class="form-group">
            <label for="description">Description</label>
            <textarea
                id="description"
                name="description"
                placeholder="Enter media description"
            ></textarea>
        </div>

        <div class="form-group">
            <label for="media_type">Media Type</label>

            <select id="media_type" name="media_type" required>
                <option value="">Select media type</option>
                <option value="video">Video</option>
                <option value="photo">Photo</option>
                <option value="audio">Audio</option>
            </select>
        </div>

        <div class="form-group">
            <label for="media_file">Choose Media File</label>

            <input
                type="file"
                id="media_file"
                name="media_file"
                accept="video/mp4,video/webm,image/jpeg,image/png,image/gif,image/webp,audio/mpeg,audio/wav,audio/ogg,audio/mp4"
                required
            >
        </div>

        <button type="submit" class="upload-button">
            Upload Media
        </button>

    </form>

</div>

</body>
</html>
