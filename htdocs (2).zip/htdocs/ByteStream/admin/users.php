
<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

if (($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: ../dashboard.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';

// Create CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message = '';

// Handle user deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';

    if (!hash_equals($_SESSION['csrf_token'], $token)) {
        $message = 'Invalid request. Please try again.';
    } else {
        $userId = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);

        if (!$userId || $userId === (int) $_SESSION['user_id']) {
            $message = 'Invalid user selection.';
        } else {
            // Only regular user accounts can be deleted here.
            $stmt = $pdo->prepare(
                "DELETE FROM users WHERE id = :id AND role = 'user'"
            );

            $stmt->execute([':id' => $userId]);

            if ($stmt->rowCount() > 0) {
                $message = 'User account deleted successfully.';
            } else {
                $message = 'User not found or cannot be deleted.';
            }
        }
    }
}

// Search users
$search = trim($_GET['search'] ?? '');

$sql = "SELECT id, username, email, created_at
        FROM users
        WHERE role = 'user'";

$params = [];

if ($search !== '') {
    $sql .= " AND (username LIKE :search OR email LIKE :search)";
    $params[':search'] = '%' . $search . '%';
}

$sql .= " ORDER BY created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

$totalUsers = (int) $pdo->query(
    "SELECT COUNT(*) FROM users WHERE role = 'user'"
)->fetchColumn();

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ByteStream - Manage Users</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

<aside class="admin-sidebar">
    <h2>ByteStream</h2>
    <p class="admin-label">ADMIN PANEL</p>

    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="users.php" class="active">Manage Users</a>
        <a href="upload.php">Upload Media</a>
        <a href="videos.php">Manage Videos</a>
        <a href="photos.php">Manage Photos</a>
        <a href="audio.php">Manage Audio</a>
    </nav>

    <div class="sidebar-bottom">
        <a href="../dashboard.php">User Website</a>
        <a href="../logout.php">Logout</a>
    </div>
</aside>

<main class="admin-main">

    <header class="admin-topbar">
        <div>
            <p class="eyebrow">BYTESTREAM MANAGEMENT</p>
            <h1>Manage Users</h1>
        </div>

        <div class="admin-profile">
            <span class="profile-icon">A</span>
            <span><?= e($_SESSION['username']) ?></span>
        </div>
    </header>

    <section class="welcome-banner">
        <p>USER MANAGEMENT</p>
        <h2>Registered Accounts</h2>
        <span>View and manage regular ByteStream user accounts.</span>
    </section>

    <?php if ($message !== ''): ?>
        <p class="admin-message"><?= e($message) ?></p>
    <?php endif; ?>

    <section class="users-section">

        <div class="users-heading">
            <div>
                <h2>User List</h2>
                <p>Total registered users: <?= $totalUsers ?></p>
            </div>

            <form method="GET" class="user-search">
                <input
                    type="search"
                    name="search"
                    placeholder="Search username or email..."
                    value="<?= e($search) ?>"
                >
                <button type="submit">Search</button>
            </form>
        </div>

        <div class="table-wrapper">
            <table class="users-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email Address</th>
                        <th>Date Registered</th>
                        <th>Role</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (count($users) > 0): ?>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?= (int) $user['id'] ?></td>
                                <td><?= e($user['username']) ?></td>
                                <td><?= e($user['email']) ?></td>
                                <td><?= e($user['created_at']) ?></td>
                                <td>
                                    <span class="role-user">User</span>
                                </td>
                                <td>
                                    <form
                                        method="POST"
                                        onsubmit="return confirm('Are you sure you want to delete this user?');"
                                    >
                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?= e($_SESSION['csrf_token']) ?>"
                                        >
                                        <input
                                            type="hidden"
                                            name="user_id"
                                            value="<?= (int) $user['id'] ?>"
                                        >
                                        <button
                                            type="submit"
                                            class="delete-button"
                                        >
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="empty-message">
                                No registered users found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </section>

</main>

</body>
</html>
