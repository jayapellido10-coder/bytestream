
<?php
session_start();

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../config/activity.php";

// Admin access only
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

if (($_SESSION["role"] ?? "") !== "admin") {
    header("Location: ../dashboard.php");
    exit;
}

$adminId = (int) $_SESSION["user_id"];

// CSRF token
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$message = "";
$messageType = "";

// Handle POST requests
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $token = $_POST["csrf_token"] ?? "";

    if (!hash_equals($_SESSION["csrf_token"], $token)) {
        http_response_code(403);
        exit("Invalid request. Please refresh the page.");
    }

    // EDIT PHOTO
    if (isset($_POST["edit_photo"])) {

        $photoId = filter_var(
            $_POST["photo_id"] ?? null,
            FILTER_VALIDATE_INT
        );

        $title = trim($_POST["title"] ?? "");
        $description = trim($_POST["description"] ?? "");
        $categoryId = $_POST["category_id"] ?? "";

        if (!$photoId || $title === "" || strlen($title) > 255) {
            $message = "Please enter a valid photo title.";
            $messageType = "error";

        } else {

            $check = $pdo->prepare("
                SELECT id FROM media
                WHERE id = ? AND media_type = 'photo'
            ");
            $check->execute([$photoId]);

            if (!$check->fetch()) {
                $message = "Photo not found.";
                $messageType = "error";

            } else {

                // Validate category
                if ($categoryId === "") {
                    $categoryId = null;

                } else {
                    $categoryId = filter_var(
                        $categoryId,
                        FILTER_VALIDATE_INT
                    );

                    if (!$categoryId) {
                        $message = "Invalid category.";
                        $messageType = "error";

                    } else {
                        $checkCategory = $pdo->prepare("
                            SELECT id FROM categories
                            WHERE id = ? AND media_type = 'photo'
                        ");
                        $checkCategory->execute([$categoryId]);

                        if (!$checkCategory->fetch()) {
                            $message = "Selected category is not valid for photos.";
                            $messageType = "error";
                        }
                    }
                }

                if ($message === "") {

                    $update = $pdo->prepare("
                        UPDATE media
                        SET title = ?, description = ?, category_id = ?
                        WHERE id = ? AND media_type = 'photo'
                    ");

                    $update->execute([
                        $title,
                        $description,
                        $categoryId,
                        $photoId
                    ]);

                    logActivity(
                        $pdo,
                        $adminId,
                        "Edited photo details: " . $title
                    );

                    $message = "Photo details updated successfully!";
                    $messageType = "success";
                }
            }
        }
    }

    // DELETE PHOTO
    elseif (isset($_POST["delete_id"])) {

        $photoId = filter_var(
            $_POST["delete_id"],
            FILTER_VALIDATE_INT
        );

        if ($photoId) {

            $stmt = $pdo->prepare("
                SELECT title, file_name
                FROM media
                WHERE id = ? AND media_type = 'photo'
            ");

            $stmt->execute([$photoId]);
            $photo = $stmt->fetch();

            if ($photo) {

                $delete = $pdo->prepare("
                    DELETE FROM media
                    WHERE id = ? AND media_type = 'photo'
                ");

                $delete->execute([$photoId]);

                $filePath = __DIR__ . "/../uploads/photos/" .
                    basename($photo["file_name"]);

                if (is_file($filePath)) {
                    unlink($filePath);
                }

                logActivity(
                    $pdo,
                    $adminId,
                    "Deleted a photo: " . $photo["title"]
                );

                $message = "Photo deleted successfully.";
                $messageType = "success";

            } else {
                $message = "Photo not found.";
                $messageType = "error";
            }

        } else {
            $message = "Invalid photo.";
            $messageType = "error";
        }
    }
}

// Get photo categories
$categoryStmt = $pdo->prepare("
    SELECT id, name
    FROM categories
    WHERE media_type = 'photo'
    ORDER BY name ASC
");
$categoryStmt->execute();
$categories = $categoryStmt->fetchAll();

// Get uploaded photos and category names
$stmt = $pdo->query("
    SELECT
        media.id,
        media.title,
        media.description,
        media.file_name,
        media.category_id,
        media.created_at,
        categories.name AS category_name
    FROM media
    LEFT JOIN categories ON media.category_id = categories.id
    WHERE media.media_type = 'photo'
    ORDER BY media.created_at DESC
");

$photos = $stmt->fetchAll();

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Manage Photos | ByteStream</title>

    <link rel="stylesheet" href="../assets/css/admin.css">

    <style>
        .edit-form {
            display: none;
            margin-top: 18px;
            padding: 18px;
            background: rgba(3, 17, 34, 0.8);
            border: 1px solid rgba(53, 217, 255, 0.3);
            border-radius: 10px;
        }

        .edit-form.show {
            display: block;
        }

        .edit-form label {
            display: block;
            margin-top: 12px;
            margin-bottom: 6px;
            color: #35d9ff;
        }

        .edit-form input,
        .edit-form textarea,
        .edit-form select {
            width: 100%;
            box-sizing: border-box;
            padding: 11px;
            border-radius: 7px;
            border: 1px solid #285273;
            background: #091c30;
            color: white;
        }

        .edit-form textarea {
            min-height: 90px;
            resize: vertical;
        }

        .edit-btn,
        .save-btn,
        .cancel-btn {
            padding: 10px 15px;
            border: none;
            border-radius: 7px;
            cursor: pointer;
            font-weight: bold;
            margin-top: 12px;
        }

        .edit-btn {
            background: #1476b8;
            color: white;
        }

        .save-btn {
            background: #00bce8;
            color: #071426;
        }

        .cancel-btn {
            background: #526477;
            color: white;
            margin-left: 5px;
        }

        .photo-category {
            color: #35d9ff;
            font-size: 13px;
        }

        .admin-message {
            padding: 12px;
            border-radius: 8px;
            margin: 15px 0;
        }

        .admin-message.success {
            color: #78ffc0;
            background: rgba(0, 200, 120, 0.12);
        }

        .admin-message.error {
            color: #ff9eaa;
            background: rgba(255, 60, 80, 0.12);
        }
    </style>
</head>

<body>

<aside class="admin-sidebar">

    <h2>ByteStream</h2>
    <p class="admin-label">ADMIN PANEL</p>

    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="users.php">Manage Users</a>
        <a href="upload.php">Upload Media</a>
        <a href="videos.php">Manage Videos</a>
        <a href="photos.php" class="active">Manage Photos</a>
        <a href="audio.php">Manage Audio</a>
        <a href="activity-logs.php">Activity Logs</a>
        <a href="categories.php">Categories</a>
    </nav>

    <div class="sidebar-bottom">
        <a href="../dashboard.php">User Website</a>
        <a href="../logout.php">Logout</a>
    </div>

</aside>

<main class="admin-main">

    <header class="admin-topbar">
        <div>
            <p class="eyebrow">BYTESTREAM MANAGEMENT</p>
            <h1>Manage Photos</h1>
        </div>

        <div class="admin-profile">
            <span class="profile-icon">A</span>
            <span>
                <?= e($_SESSION["username"]) ?>
            </span>
        </div>
    </header>

    <section class="overview-section">

        <h2>Photo Gallery Management</h2>

        <p style="color: #b9c9d9;">
            View, edit, and organize all uploaded photos in ByteStream.
        </p>

        <?php if ($message): ?>
            <div class="admin-message <?= e($messageType) ?>">
                <?= e($message) ?>
            </div>
        <?php endif; ?>

        <div class="media-grid">

            <?php if (empty($photos)): ?>

                <p class="empty-message">
                    No photos have been uploaded yet.
                </p>

            <?php else: ?>

                <?php foreach ($photos as $photo): ?>

                    <article class="media-card">

                        <img
                            src="../uploads/photos/<?= rawurlencode(basename($photo["file_name"])) ?>"
                            alt="<?= e($photo["title"]) ?>"
                            loading="lazy"
                        >

                        <h3><?= e($photo["title"]) ?></h3>

                        <p><?= e($photo["description"]) ?></p>

                        <p class="photo-category">
                            Category:
                            <?= e($photo["category_name"] ?? "Uncategorized") ?>
                        </p>

                        <p>
                            <small>
                                Uploaded:
                                <?= e(date("M d, Y", strtotime($photo["created_at"]))) ?>
                            </small>
                        </p>

                        <!-- EDIT BUTTON -->
                        <button
                            type="button"
                            class="edit-btn"
                            onclick="toggleEdit(<?= (int)$photo['id'] ?>)"
                        >
                            Edit Photo
                        </button>

                        <!-- EDIT FORM -->
                        <form
                            method="POST"
                            id="edit-<?= (int)$photo['id'] ?>"
                            class="edit-form"
                        >

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= e($_SESSION["csrf_token"]) ?>"
                            >

                            <input
                                type="hidden"
                                name="photo_id"
                                value="<?= (int)$photo["id"] ?>"
                            >

                            <label>Photo Title</label>

                            <input
                                type="text"
                                name="title"
                                maxlength="255"
                                value="<?= e($photo["title"]) ?>"
                                required
                            >

                            <label>Description</label>

                            <textarea name="description"><?= e($photo["description"]) ?></textarea>

                            <label>Category</label>

                            <select name="category_id">
                                <option value="">Uncategorized</option>

                                <?php foreach ($categories as $category): ?>
                                    <option
                                        value="<?= (int)$category["id"] ?>"
                                        <?= (string)$photo["category_id"] === (string)$category["id"] ? "selected" : "" ?>
                                    >
                                        <?= e($category["name"]) ?>
                                    </option>
                                <?php endforeach; ?>

                            </select>

                            <button
                                type="submit"
                                name="edit_photo"
                                class="save-btn"
                            >
                                Save Changes
                            </button>

                            <button
                                type="button"
                                class="cancel-btn"
                                onclick="toggleEdit(<?= (int)$photo['id'] ?>)"
                            >
                                Cancel
                            </button>

                        </form>

                        <!-- DELETE FORM -->
                        <form
                            method="POST"
                            onsubmit="return confirm('Are you sure you want to delete this photo?');"
                        >

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= e($_SESSION["csrf_token"]) ?>"
                            >

                            <input
                                type="hidden"
                                name="delete_id"
                                value="<?= (int)$photo["id"] ?>"
                            >

                            <button type="submit">
                                Delete Photo
                            </button>

                        </form>

                    </article>

                <?php endforeach; ?>

            <?php endif; ?>

        </div>

    </section>

</main>

<script>
function toggleEdit(photoId) {
    const form = document.getElementById("edit-" + photoId);

    if (form) {
        form.classList.toggle("show");
    }
}
</script>

</body>
</html>
