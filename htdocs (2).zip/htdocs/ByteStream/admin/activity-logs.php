
<?php
session_start();

require_once __DIR__ . "/../config/database.php";

// Admin access only
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: ../login.php");
    exit;
}

// Pagination
$limit = 15;
$page = max(1, (int)($_GET["page"] ?? 1));

$countStmt = $pdo->query("SELECT COUNT(*) FROM activity_logs");
$totalLogs = (int)$countStmt->fetchColumn();

$totalPages = max(1, (int)ceil($totalLogs / $limit));
$page = min($page, $totalPages);
$offset = ($page - 1) * $limit;

// Get activity logs
$stmt = $pdo->prepare("
    SELECT
        activity_logs.id,
        activity_logs.action,
        activity_logs.created_at,
        users.username
    FROM activity_logs
    LEFT JOIN users ON activity_logs.user_id = users.id
    ORDER BY activity_logs.created_at DESC, activity_logs.id DESC
    LIMIT :limit OFFSET :offset
");

$stmt->bindValue(":limit", $limit, PDO::PARAM_INT);
$stmt->bindValue(":offset", $offset, PDO::PARAM_INT);
$stmt->execute();

$logs = $stmt->fetchAll();

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activity Logs | ByteStream</title>
    <link rel="stylesheet" href="../assets/css/admin.css">

    <style>
        .logs-container {
            padding: 30px;
        }

        .logs-header {
            margin-bottom: 25px;
        }

        .logs-header h1 {
            color: #35d9ff;
            margin-bottom: 8px;
        }

        .logs-summary {
            background: rgba(15, 35, 60, 0.9);
            border: 1px solid rgba(53, 217, 255, 0.3);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
        }

        .logs-summary h2 {
            color: #35d9ff;
            margin: 0 0 8px;
        }

        .logs-table-wrapper {
            overflow-x: auto;
            background: rgba(15, 35, 60, 0.9);
            border: 1px solid rgba(53, 217, 255, 0.25);
            border-radius: 12px;
            padding: 15px;
        }

        .logs-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 600px;
        }

        .logs-table th,
        .logs-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .logs-table th {
            color: #35d9ff;
            background: rgba(0, 190, 255, 0.08);
        }

        .logs-table td {
            color: #eaf6ff;
        }

        .logs-table tr:hover {
            background: rgba(53, 217, 255, 0.05);
        }

        .activity-badge {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 20px;
            background: rgba(53, 217, 255, 0.12);
            color: #35d9ff;
            font-size: 12px;
        }

        .pagination {
            display: flex;
            gap: 10px;
            justify-content: center;
            align-items: center;
            margin-top: 25px;
            flex-wrap: wrap;
        }

        .pagination a {
            padding: 9px 15px;
            color: #35d9ff;
            text-decoration: none;
            border: 1px solid #35d9ff;
            border-radius: 7px;
        }

        .pagination a:hover {
            background: #35d9ff;
            color: #071426;
        }

        .pagination .current {
            color: white;
            font-weight: bold;
        }

        .empty-logs {
            text-align: center !important;
            padding: 35px !important;
            color: #9eb8d0 !important;
        }

        @media (max-width: 700px) {
            .logs-container {
                padding: 15px;
            }
        }
    </style>
</head>

<body>

<div class="logs-container">

    <div class="logs-header">
        <h1>Activity Logs</h1>
        <p>Monitor user and administrator activities in ByteStream.</p>
    </div>

    <div class="logs-summary">
        <h2><?= number_format($totalLogs) ?></h2>
        <p>Total Recorded Activities</p>
    </div>

    <div class="logs-table-wrapper">

        <table class="logs-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Activity</th>
                    <th>Date and Time</th>
                </tr>
            </thead>

            <tbody>
                <?php if (count($logs) > 0): ?>

                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?= e($log["id"]) ?></td>

                            <td>
                                <?= e($log["username"] ?? "Deleted User") ?>
                            </td>

                            <td>
                                <span class="activity-badge">
                                    <?= e($log["action"]) ?>
                                </span>
                            </td>

                            <td>
                                <?= e(date(
                                    "M d, Y - h:i A",
                                    strtotime($log["created_at"])
                                )) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                <?php else: ?>
                    <tr>
                        <td colspan="4" class="empty-logs">
                            No activities recorded yet.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

    </div>

    <?php if ($totalPages > 1): ?>
        <div class="pagination">

            <?php if ($page > 1): ?>
                <a href="?page=<?= $page - 1 ?>">Previous</a>
            <?php endif; ?>

            <span class="current">
                Page <?= $page ?> of <?= $totalPages ?>
            </span>

            <?php if ($page < $totalPages): ?>
                <a href="?page=<?= $page + 1 ?>">Next</a>
            <?php endif; ?>

        </div>
    <?php endif; ?>

    <p style="margin-top: 25px;">
        <a href="dashboard.php" style="color:#35d9ff;text-decoration:none;">
            ← Back to Admin Dashboard
        </a>
    </p>

</div>

</body>
</html>
