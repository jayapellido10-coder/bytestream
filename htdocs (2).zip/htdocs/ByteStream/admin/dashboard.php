
<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

if (($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: ../dashboard.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';

// Get current admin information
$stmt = $pdo->prepare("
    SELECT username, profile_picture
    FROM users
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([$_SESSION['user_id']]);
$currentAdmin = $stmt->fetch();

$username = htmlspecialchars(
    $currentAdmin['username'] ?? $_SESSION['username'] ?? 'Admin',
    ENT_QUOTES,
    'UTF-8'
);

// Get admin profile picture
if (!empty($currentAdmin['profile_picture'])) {
    $profilePicture = '../uploads/profiles/' .
        rawurlencode(basename($currentAdmin['profile_picture']));
} else {
    $profilePicture = '../assets/images/default-avatar.png';
}

// Dashboard statistics
$totalUsers = (int) $pdo->query(
    "SELECT COUNT(*) FROM users WHERE role = 'user'"
)->fetchColumn();

$totalVideos = (int) $pdo->query(
    "SELECT COUNT(*) FROM media WHERE media_type = 'video'"
)->fetchColumn();

$totalPhotos = (int) $pdo->query(
    "SELECT COUNT(*) FROM media WHERE media_type = 'photo'"
)->fetchColumn();

$totalAudio = (int) $pdo->query(
    "SELECT COUNT(*) FROM media WHERE media_type = 'audio'"
)->fetchColumn();

$totalMedia = $totalVideos + $totalPhotos + $totalAudio;

$totalActivities = (int) $pdo->query(
    "SELECT COUNT(*) FROM activity_logs"
)->fetchColumn();

$recentActivities = $pdo->query("
    SELECT
        activity_logs.action,
        activity_logs.created_at,
        users.username
    FROM activity_logs
    LEFT JOIN users ON activity_logs.user_id = users.id
    ORDER BY activity_logs.created_at DESC
    LIMIT 5
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>ByteStream - Admin Dashboard</title>

    <link rel="stylesheet" href="../assets/css/admin.css">

    <style>
        .activity-section {
            margin-top: 35px;
        }

        .activity-section h2 {
            margin-bottom: 20px;
        }

        .activity-item {
            background: #101d31;
            border: 1px solid rgba(0, 234, 255, .25);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 12px;
        }

        .activity-item strong {
            color: #00eaff;
        }

        .activity-item p {
            margin: 8px 0;
        }

        .activity-item small {
            color: #a9b6c9;
        }

        .view-all-activities {
            display: inline-block;
            margin-top: 12px;
            color: #00eaff;
            text-decoration: none;
        }

        .view-all-activities:hover {
            color: #b69aff;
        }

        /* Admin Sidebar Profile */
        .admin-sidebar-profile {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 13px;
            margin: 15px 0 20px;
            border: 1px solid rgba(0, 234, 255, .3);
            border-radius: 12px;
            background: #101d31;
            text-decoration: none;
            color: white;
            transition: .2s;
        }

        .admin-sidebar-profile:hover {
            border-color: #00eaff;
            box-shadow: 0 0 15px #00eaff33;
        }

        .admin-sidebar-profile img {
            width: 43px;
            height: 43px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #00eaff;
        }

        .admin-sidebar-profile-info {
            min-width: 0;
        }

        .admin-sidebar-profile-info strong {
            display: block;
            font-size: 14px;
            overflow-wrap: anywhere;
        }

        .admin-sidebar-profile-info small {
            display: block;
            color: #00eaff;
            font-size: 11px;
            margin-top: 4px;
        }

        /* Admin Topbar Profile */
        .admin-profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .admin-profile-link {
            display: flex;
            align-items: center;
            gap: 10px;
            color: white;
            text-decoration: none;
            font-weight: 600;
        }

        .admin-profile-link img {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #00eaff;
            box-shadow: 0 0 12px #00eaff44;
        }

        .admin-profile-link:hover {
            color: #00eaff;
        }

        @media (max-width: 500px) {
            .admin-profile-link span {
                display: none;
            }
        }

        .back-dashboard {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 11px 20px;
    margin-bottom: 22px;
    color: #00eaff;
    background: rgba(0, 234, 255, 0.07);
    border: 1px solid rgba(0, 234, 255, 0.35);
    border-radius: 10px;
    text-decoration: none;
    font-size: 14px;
    font-weight: 600;
    letter-spacing: 0.3px;
    transition: all 0.3s ease;
}

.back-dashboard:hover {
    color: #07111f;
    background: #00eaff;
    border-color: #00eaff;
    box-shadow: 0 0 18px rgba(0, 234, 255, 0.3);
    transform: translateX(-3px);
}

.back-icon {
    font-size: 19px;
    line-height: 1;
}
    </style>

</head>

<body>

<aside class="admin-sidebar">

    <h2>ByteStream</h2>
    <p class="admin-label">ADMIN PANEL</p>

    <a href="account.php" class="admin-sidebar-profile">
        <img
            src="<?= htmlspecialchars($profilePicture, ENT_QUOTES, 'UTF-8') ?>"
            alt="Admin Profile Picture"
        >

        <div class="admin-sidebar-profile-info">
            <strong><?= $username ?></strong>
            <small>View Admin Profile</small>
        </div>
    </a>

    <nav>
        <a href="dashboard.php" class="active">Dashboard</a>
        <a href="users.php">Manage Users</a>
        <a href="upload.php">Upload Media</a>
        <a href="videos.php">Manage Videos</a>
        <a href="photos.php">Manage Photos</a>
        <a href="audio.php">Manage Audio</a>
        <a href="activity-logs.php">Activity Logs</a>
        <a href="account.php">My Account</a>
    </nav>

    <div class="sidebar-bottom">
        <a href="../dashboard.php">User Website</a>
        <a href="../logout.php">Logout</a>
    </div>

</aside>

<main class="admin-main">

    <header class="admin-topbar">

        <div>
            <p class="eyebrow">BYTESTREAM MANAGEMENT</p>
            <h1>Admin Dashboard</h1>
        </div>

        <div class="admin-profile">
            <a href="account.php" class="admin-profile-link">
                <img
                    src="<?= htmlspecialchars($profilePicture, ENT_QUOTES, 'UTF-8') ?>"
                    alt="Admin Profile Picture"
                >
                <span><?= $username ?></span>
            </a>
        </div>

    </header>

    <section class="welcome-banner">

        <p>WELCOME BACK, ADMIN</p>

        <h2>Manage Your Digital Media Hub</h2>

        <span>
            Monitor users, organize media, and manage ByteStream
            from one place.
        </span>

    </section>

    <section class="overview-section">

        <h2>Overview</h2>

        <div class="stats-grid">

            <article class="stat-card">
                <span class="stat-icon">👥</span>
                <p>Regular Users</p>
                <h3><?= $totalUsers ?></h3>
            </article>

            <article class="stat-card">
                <span class="stat-icon">▣</span>
                <p>Total Media</p>
                <h3><?= $totalMedia ?></h3>
            </article>

            <article class="stat-card">
                <span class="stat-icon">▶</span>
                <p>Videos</p>
                <h3><?= $totalVideos ?></h3>
            </article>

            <article class="stat-card">
                <span class="stat-icon">▧</span>
                <p>Photos</p>
                <h3><?= $totalPhotos ?></h3>
            </article>

            <article class="stat-card">
                <span class="stat-icon">♫</span>
                <p>Audio Files</p>
                <h3><?= $totalAudio ?></h3>
            </article>

            <article class="stat-card">
                <span class="stat-icon">📋</span>
                <p>Activity Records</p>
                <h3><?= $totalActivities ?></h3>
            </article>

        </div>

    </section>

    <section class="management-section">

        <h2>Quick Management</h2>

        <div class="management-grid">

            <a href="users.php" class="management-card">
                <span>👥</span>
                <h3>Manage Users</h3>
                <p>View and manage registered accounts.</p>
            </a>

            <a href="upload.php" class="management-card">
                <span>⬆</span>
                <h3>Upload Media</h3>
                <p>Add new videos, photos, and audio.</p>
            </a>

            <a href="videos.php" class="management-card">
                <span>▶</span>
                <h3>Manage Videos</h3>
                <p>Organize uploaded video content.</p>
            </a>

            <a href="photos.php" class="management-card">
                <span>▧</span>
                <h3>Manage Photos</h3>
                <p>Organize the photo gallery.</p>
            </a>

            <a href="audio.php" class="management-card">
                <span>♫</span>
                <h3>Manage Audio</h3>
                <p>Organize uploaded audio files.</p>
            </a>

            <a href="activity-logs.php" class="management-card">
                <span>📋</span>
                <h3>Activity Logs</h3>
                <p>Monitor login, registration, upload, and logout activities.</p>
            </a>

        </div>

    </section>

    <section class="activity-section">

        <h2>Recent Activities</h2>

        <?php if (empty($recentActivities)): ?>

            <p>No activities recorded yet.</p>

        <?php else: ?>

            <?php foreach ($recentActivities as $activity): ?>

                <div class="activity-item">

                    <p>
                        <strong>
                            <?= htmlspecialchars(
                                $activity['username'] ?? 'Deleted User',
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </strong>
                    </p>

                    <p>
                        <?= htmlspecialchars(
                            $activity['action'],
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>
                    </p>

                    <small>
                        <?= date(
                            'F d, Y - h:i A',
                            strtotime($activity['created_at'])
                        ) ?>
                    </small>

                </div>

            <?php endforeach; ?>

        <?php endif; ?>

        <a href="activity-logs.php" class="view-all-activities">
            View All Activities →
        </a>

    </section>

</main>

</body>
</html>
