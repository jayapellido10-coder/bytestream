
<?php
session_start();

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../config/activity.php";

// Admin access only
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: ../login.php");
    exit;
}

$adminId = (int) $_SESSION["user_id"];

// CSRF token
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$message = "";
$messageType = "";

// Handle POST requests
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $token = $_POST["csrf_token"] ?? "";

    if (!hash_equals($_SESSION["csrf_token"], $token)) {
        die("Invalid request. Please refresh the page.");
    }

    // EDIT VIDEO
    if (isset($_POST["edit_video"])) {

        $videoId = filter_var(
            $_POST["video_id"] ?? null,
            FILTER_VALIDATE_INT
        );

        $title = trim($_POST["title"] ?? "");
        $description = trim($_POST["description"] ?? "");
        $categoryId = $_POST["category_id"] ?? "";

        if (!$videoId || $title === "" || strlen($title) > 255) {
            $message = "Please enter a valid video title.";
            $messageType = "error";

        } else {

            $check = $pdo->prepare(
                "SELECT id FROM media WHERE id = ? AND media_type = 'video'"
            );
            $check->execute([$videoId]);

            if (!$check->fetch()) {
                $message = "Video not found.";
                $messageType = "error";

            } else {

                // Validate category
                if ($categoryId === "") {
                    $categoryId = null;
                } else {
                    $categoryId = filter_var(
                        $categoryId,
                        FILTER_VALIDATE_INT
                    );

                    if (!$categoryId) {
                        $message = "Invalid category.";
                        $messageType = "error";
                    } else {
                        $checkCategory = $pdo->prepare(
                            "SELECT id FROM categories
                             WHERE id = ? AND media_type = 'video'"
                        );
                        $checkCategory->execute([$categoryId]);

                        if (!$checkCategory->fetch()) {
                            $message = "Selected category is not valid for videos.";
                            $messageType = "error";
                        }
                    }
                }

                if ($message === "") {

                    $update = $pdo->prepare(
                        "UPDATE media
                         SET title = ?, description = ?, category_id = ?
                         WHERE id = ? AND media_type = 'video'"
                    );

                    $update->execute([
                        $title,
                        $description,
                        $categoryId,
                        $videoId
                    ]);

                    logActivity(
                        $pdo,
                        $adminId,
                        "Edited video details: " . $title
                    );

                    $message = "Video details updated successfully!";
                    $messageType = "success";
                }
            }
        }
    }

    // DELETE VIDEO
    elseif (isset($_POST["delete_video"])) {

        $videoId = filter_var(
            $_POST["video_id"] ?? null,
            FILTER_VALIDATE_INT
        );

        if ($videoId) {

            $stmt = $pdo->prepare(
                "SELECT title, file_name
                 FROM media
                 WHERE id = ? AND media_type = 'video'"
            );

            $stmt->execute([$videoId]);
            $video = $stmt->fetch();

            if ($video) {

                $delete = $pdo->prepare(
                    "DELETE FROM media
                     WHERE id = ? AND media_type = 'video'"
                );

                $delete->execute([$videoId]);

                $filePath = __DIR__ . "/../uploads/videos/" .
                    basename($video["file_name"]);

                if (is_file($filePath)) {
                    unlink($filePath);
                }

                logActivity(
                    $pdo,
                    $adminId,
                    "Deleted video: " . $video["title"]
                );

                $message = "Video deleted successfully!";
                $messageType = "success";

            } else {
                $message = "Video not found.";
                $messageType = "error";
            }

        } else {
            $message = "Invalid video.";
            $messageType = "error";
        }
    }
}

// Get video categories
$categoryStmt = $pdo->prepare(
    "SELECT id, name FROM categories
     WHERE media_type = 'video'
     ORDER BY name ASC"
);
$categoryStmt->execute();
$categories = $categoryStmt->fetchAll();

// Get uploaded videos with category names
$stmt = $pdo->prepare(
    "SELECT media.*, categories.name AS category_name
     FROM media
     LEFT JOIN categories ON media.category_id = categories.id
     WHERE media.media_type = 'video'
     ORDER BY media.created_at DESC"
);

$stmt->execute();
$videos = $stmt->fetchAll();

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Manage Videos | ByteStream</title>

    <link rel="stylesheet" href="../assets/css/admin.css">

    <style>
        .edit-form {
            display: none;
            margin-top: 18px;
            padding: 18px;
            background: rgba(3, 17, 34, 0.8);
            border: 1px solid rgba(53, 217, 255, 0.3);
            border-radius: 10px;
        }

        .edit-form.show {
            display: block;
        }

        .edit-form label {
            display: block;
            margin-top: 12px;
            margin-bottom: 6px;
            color: #35d9ff;
        }

        .edit-form input,
        .edit-form textarea,
        .edit-form select {
            width: 100%;
            box-sizing: border-box;
            padding: 11px;
            border-radius: 7px;
            border: 1px solid #285273;
            background: #091c30;
            color: white;
        }

        .edit-form textarea {
            min-height: 90px;
            resize: vertical;
        }

        .edit-btn,
        .save-btn,
        .cancel-btn {
            padding: 10px 15px;
            border: none;
            border-radius: 7px;
            cursor: pointer;
            font-weight: bold;
            margin-top: 12px;
        }

        .edit-btn {
            background: #1476b8;
            color: white;
        }

        .save-btn {
            background: #00bce8;
            color: #071426;
        }

        .cancel-btn {
            background: #526477;
            color: white;
            margin-left: 5px;
        }

        .success-message {
            color: #78ffc0;
            background: rgba(0, 200, 120, 0.12);
            padding: 12px;
            border-radius: 8px;
        }

        .error-message {
            color: #ff9eaa;
            background: rgba(255, 60, 80, 0.12);
            padding: 12px;
            border-radius: 8px;
        }

        .video-category {
            color: #35d9ff;
            font-size: 13px;
        }
    </style>
</head>

<body>

<div class="admin-container">

    <h1>Manage Videos</h1>
    <p>View, edit, and manage uploaded videos in ByteStream.</p>

    <a href="dashboard.php">← Back to Admin Dashboard</a>
    <a href="upload.php">Upload New Media</a>

    <?php if ($message): ?>
        <p class="<?= $messageType === 'success' ? 'success-message' : 'error-message' ?>">
            <?= e($message) ?>
        </p>
    <?php endif; ?>

    <div class="media-grid">

        <?php if (empty($videos)): ?>

            <p>No videos uploaded yet.</p>

        <?php else: ?>

            <?php foreach ($videos as $video): ?>

                <div class="media-card">

                    <video controls preload="metadata">
                        <source
                            src="../uploads/videos/<?= rawurlencode(basename($video["file_name"])) ?>"
                        >
                        Your browser does not support video playback.
                    </video>

                    <h3><?= e($video["title"]) ?></h3>

                    <p><?= e($video["description"]) ?></p>

                    <p class="video-category">
                        Category:
                        <?= e($video["category_name"] ?? "Uncategorized") ?>
                    </p>

                    <small>
                        Uploaded: <?= e($video["created_at"]) ?>
                    </small>

                    <!-- EDIT BUTTON -->
                    <button
                        type="button"
                        class="edit-btn"
                        onclick="toggleEdit(<?= (int)$video['id'] ?>)"
                    >
                        Edit Video
                    </button>

                    <!-- EDIT FORM -->
                    <form method="POST"
                          id="edit-<?= (int)$video['id'] ?>"
                          class="edit-form">

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= e($_SESSION["csrf_token"]) ?>"
                        >

                        <input
                            type="hidden"
                            name="video_id"
                            value="<?= (int)$video["id"] ?>"
                        >

                        <label>Video Title</label>

                        <input
                            type="text"
                            name="title"
                            maxlength="255"
                            value="<?= e($video["title"]) ?>"
                            required
                        >

                        <label>Description</label>

                        <textarea name="description"><?= e($video["description"]) ?></textarea>

                        <label>Category</label>

                        <select name="category_id">
                            <option value="">Uncategorized</option>

                            <?php foreach ($categories as $category): ?>
                                <option
                                    value="<?= (int)$category["id"] ?>"
                                    <?= (string)$video["category_id"] === (string)$category["id"] ? "selected" : "" ?>
                                >
                                    <?= e($category["name"]) ?>
                                </option>
                            <?php endforeach; ?>

                        </select>

                        <button
                            type="submit"
                            name="edit_video"
                            class="save-btn"
                        >
                            Save Changes
                        </button>

                        <button
                            type="button"
                            class="cancel-btn"
                            onclick="toggleEdit(<?= (int)$video['id'] ?>)"
                        >
                            Cancel
                        </button>

                    </form>

                    <!-- DELETE FORM -->
                    <form method="POST"
                          onsubmit="return confirm('Are you sure you want to delete this video?');">

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= e($_SESSION["csrf_token"]) ?>"
                        >

                        <input
                            type="hidden"
                            name="video_id"
                            value="<?= (int)$video["id"] ?>"
                        >

                        <button type="submit" name="delete_video">
                            Delete Video
                        </button>

                    </form>

                </div>

            <?php endforeach; ?>

        <?php endif; ?>

    </div>

</div>

<script>
function toggleEdit(videoId) {
    const form = document.getElementById("edit-" + videoId);

    if (form) {
        form.classList.toggle("show");
    }
}
</script>

</body>
</html>
