
<?php
session_start();

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../config/activity.php";

// Admin access only
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

if (($_SESSION["role"] ?? "") !== "admin") {
    header("Location: ../dashboard.php");
    exit;
}

$adminId = (int) $_SESSION["user_id"];

// CSRF token
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$message = "";
$messageType = "";

// Handle POST requests
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $token = $_POST["csrf_token"] ?? "";

    if (!hash_equals($_SESSION["csrf_token"], $token)) {
        http_response_code(403);
        exit("Invalid request. Please refresh the page.");
    }

    // EDIT AUDIO
    if (isset($_POST["edit_audio"])) {

        $audioId = filter_var(
            $_POST["audio_id"] ?? null,
            FILTER_VALIDATE_INT
        );

        $title = trim($_POST["title"] ?? "");
        $description = trim($_POST["description"] ?? "");
        $categoryId = $_POST["category_id"] ?? "";

        if (!$audioId || $title === "" || strlen($title) > 255) {
            $message = "Please enter a valid audio title.";
            $messageType = "error";

        } else {

            $check = $pdo->prepare("
                SELECT id FROM media
                WHERE id = ? AND media_type = 'audio'
            ");
            $check->execute([$audioId]);

            if (!$check->fetch()) {
                $message = "Audio not found.";
                $messageType = "error";

            } else {

                // Validate category
                if ($categoryId === "") {
                    $categoryId = null;

                } else {
                    $categoryId = filter_var(
                        $categoryId,
                        FILTER_VALIDATE_INT
                    );

                    if (!$categoryId) {
                        $message = "Invalid category.";
                        $messageType = "error";

                    } else {
                        $checkCategory = $pdo->prepare("
                            SELECT id FROM categories
                            WHERE id = ? AND media_type = 'audio'
                        ");
                        $checkCategory->execute([$categoryId]);

                        if (!$checkCategory->fetch()) {
                            $message = "Selected category is not valid for audio.";
                            $messageType = "error";
                        }
                    }
                }

                if ($message === "") {

                    $update = $pdo->prepare("
                        UPDATE media
                        SET title = ?, description = ?, category_id = ?
                        WHERE id = ? AND media_type = 'audio'
                    ");

                    $update->execute([
                        $title,
                        $description,
                        $categoryId,
                        $audioId
                    ]);

                    logActivity(
                        $pdo,
                        $adminId,
                        "Edited audio details: " . $title
                    );

                    $message = "Audio details updated successfully!";
                    $messageType = "success";
                }
            }
        }
    }

    // DELETE AUDIO
    elseif (isset($_POST["delete_id"])) {

        $audioId = filter_var(
            $_POST["delete_id"],
            FILTER_VALIDATE_INT
        );

        if ($audioId) {

            $stmt = $pdo->prepare("
                SELECT title, file_name
                FROM media
                WHERE id = ? AND media_type = 'audio'
            ");

            $stmt->execute([$audioId]);
            $audio = $stmt->fetch();

            if ($audio) {

                $delete = $pdo->prepare("
                    DELETE FROM media
                    WHERE id = ? AND media_type = 'audio'
                ");

                $delete->execute([$audioId]);

                $filePath = __DIR__ . "/../uploads/audio/" .
                    basename($audio["file_name"]);

                if (is_file($filePath)) {
                    unlink($filePath);
                }

                logActivity(
                    $pdo,
                    $adminId,
                    "Deleted audio: " . $audio["title"]
                );

                $message = "Audio deleted successfully.";
                $messageType = "success";

            } else {
                $message = "Audio not found.";
                $messageType = "error";
            }

        } else {
            $message = "Invalid audio.";
            $messageType = "error";
        }
    }
}

// Get audio categories
$categoryStmt = $pdo->prepare("
    SELECT id, name
    FROM categories
    WHERE media_type = 'audio'
    ORDER BY name ASC
");
$categoryStmt->execute();
$categories = $categoryStmt->fetchAll();

// Get uploaded audio
$stmt = $pdo->query("
    SELECT
        media.id,
        media.title,
        media.description,
        media.file_name,
        media.category_id,
        media.created_at,
        categories.name AS category_name
    FROM media
    LEFT JOIN categories ON media.category_id = categories.id
    WHERE media.media_type = 'audio'
    ORDER BY media.created_at DESC
");

$audios = $stmt->fetchAll();

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Manage Audio | ByteStream</title>

    <link rel="stylesheet" href="../assets/css/admin.css">

    <style>
        body {
            margin: 0;
            padding: 25px;
            background: #07111f;
            color: white;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 1100px;
            margin: auto;
        }

        h1 {
            color: #00eaff;
        }

        .audio-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 25px;
        }

        .audio-card {
            padding: 20px;
            background: #101d31;
            border: 1px solid rgba(0, 234, 255, .3);
            border-radius: 12px;
            min-width: 0;
        }

        .audio-card h3 {
            color: #00eaff;
        }

        .audio-card audio {
            width: 100%;
            margin-top: 12px;
        }

        .delete-button {
            padding: 9px 15px;
            background: #e63946;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            margin-top: 12px;
        }

        .edit-button,
        .save-button,
        .cancel-button {
            padding: 9px 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            margin-top: 12px;
        }

        .edit-button {
            background: #1476b8;
            color: white;
        }

        .save-button {
            background: #00bce8;
            color: #071426;
        }

        .cancel-button {
            background: #526477;
            color: white;
            margin-left: 5px;
        }

        .edit-form {
            display: none;
            margin-top: 18px;
            padding: 18px;
            background: #091c30;
            border: 1px solid rgba(0, 234, 255, .3);
            border-radius: 10px;
        }

        .edit-form.show {
            display: block;
        }

        .edit-form label {
            display: block;
            margin-top: 12px;
            margin-bottom: 6px;
            color: #00eaff;
        }

        .edit-form input,
        .edit-form textarea,
        .edit-form select {
            width: 100%;
            box-sizing: border-box;
            padding: 11px;
            border-radius: 7px;
            border: 1px solid #285273;
            background: #101d31;
            color: white;
        }

        .edit-form textarea {
            min-height: 90px;
            resize: vertical;
        }

        .back-link {
            display: inline-block;
            margin: 15px 0;
            color: #00eaff;
            text-decoration: none;
        }

        .message {
            padding: 12px;
            border-radius: 8px;
            margin: 15px 0;
        }

        .message.success {
            color: #66ff99;
            background: rgba(0, 200, 120, .12);
        }

        .message.error {
            color: #ff9eaa;
            background: rgba(255, 60, 80, .12);
        }

        .audio-category {
            color: #00eaff;
            font-size: 13px;
        }

        @media (max-width: 600px) {
            body {
                padding: 15px;
            }
        }
    </style>
</head>

<body>

<div class="container">

    <h1>Manage Audio</h1>
    <p>View, edit, and manage all uploaded audio files.</p>

    <a class="back-link" href="dashboard.php">
        ← Back to Admin Dashboard
    </a>

    <?php if ($message): ?>
        <p class="message <?= e($messageType) ?>">
            <?= e($message) ?>
        </p>
    <?php endif; ?>

    <?php if (empty($audios)): ?>

        <p>No audio files have been uploaded yet.</p>

    <?php else: ?>

        <div class="audio-grid">

            <?php foreach ($audios as $audio): ?>

                <article class="audio-card">

                    <h3><?= e($audio["title"]) ?></h3>

                    <p><?= e($audio["description"]) ?></p>

                    <p class="audio-category">
                        Category:
                        <?= e($audio["category_name"] ?? "Uncategorized") ?>
                    </p>

                    <audio controls preload="metadata">
                        <source
                            src="../uploads/audio/<?= rawurlencode(basename($audio["file_name"])) ?>"
                        >
                        Your browser does not support audio playback.
                    </audio>

                    <p>
                        <small>
                            Uploaded:
                            <?= e(date("M d, Y", strtotime($audio["created_at"]))) ?>
                        </small>
                    </p>

                    <!-- EDIT BUTTON -->
                    <button
                        type="button"
                        class="edit-button"
                        onclick="toggleEdit(<?= (int)$audio['id'] ?>)"
                    >
                        Edit Audio
                    </button>

                    <!-- EDIT FORM -->
                    <form
                        method="POST"
                        id="edit-<?= (int)$audio['id'] ?>"
                        class="edit-form"
                    >

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= e($_SESSION["csrf_token"]) ?>"
                        >

                        <input
                            type="hidden"
                            name="audio_id"
                            value="<?= (int)$audio["id"] ?>"
                        >

                        <label>Audio Title</label>

                        <input
                            type="text"
                            name="title"
                            maxlength="255"
                            value="<?= e($audio["title"]) ?>"
                            required
                        >

                        <label>Description</label>

                        <textarea name="description"><?= e($audio["description"]) ?></textarea>

                        <label>Category</label>

                        <select name="category_id">
                            <option value="">Uncategorized</option>

                            <?php foreach ($categories as $category): ?>
                                <option
                                    value="<?= (int)$category["id"] ?>"
                                    <?= (string)$audio["category_id"] === (string)$category["id"] ? "selected" : "" ?>
                                >
                                    <?= e($category["name"]) ?>
                                </option>
                            <?php endforeach; ?>

                        </select>

                        <button
                            type="submit"
                            name="edit_audio"
                            class="save-button"
                        >
                            Save Changes
                        </button>

                        <button
                            type="button"
                            class="cancel-button"
                            onclick="toggleEdit(<?= (int)$audio['id'] ?>)"
                        >
                            Cancel
                        </button>

                    </form>

                    <!-- DELETE FORM -->
                    <form
                        method="POST"
                        onsubmit="return confirm('Are you sure you want to delete this audio?');"
                    >

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= e($_SESSION["csrf_token"]) ?>"
                        >

                        <input
                            type="hidden"
                            name="delete_id"
                            value="<?= (int)$audio["id"] ?>"
                        >

                        <button class="delete-button" type="submit">
                            Delete Audio
                        </button>

                    </form>

                </article>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

</div>

<script>
function toggleEdit(audioId) {
    const form = document.getElementById("edit-" + audioId);

    if (form) {
        form.classList.toggle("show");
    }
}
</script>

</body>
</html>
